#!/bin/bash
# WormGPT Enhanced — Uninstaller
echo "🗑  Removing WormGPT Enhanced..."

systemctl --user stop wormgpt 2>/dev/null || true
systemctl --user disable wormgpt 2>/dev/null || true
rm -f ~/.config/systemd/user/wormgpt.service
systemctl --user daemon-reload 2>/dev/null || true
rm -f ~/.local/share/applications/wormgpt-enhanced.desktop
update-desktop-database ~/.local/share/applications 2>/dev/null || true
pkill -f "node.*index.js" 2>/dev/null || true
pkill -x ollama 2>/dev/null || true

echo "✅ Done. App folder not deleted — remove it manually if desired."

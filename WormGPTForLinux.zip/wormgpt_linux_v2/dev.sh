#!/bin/bash
# WormGPT Enhanced — Dev Mode (hot-reload)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "🔧 WormGPT Dev Mode (hot-reload)..."

# Install deps if needed
if [ ! -d "$SCRIPT_DIR/server/node_modules" ]; then
  echo "Installing server deps..."
  cd "$SCRIPT_DIR/server" && npm install
fi
if [ ! -d "$SCRIPT_DIR/app/node_modules" ]; then
  echo "Installing app deps..."
  cd "$SCRIPT_DIR/app" && npm install
fi

# Start Ollama if available and not running
if command -v ollama &>/dev/null && ! pgrep -x "ollama" &>/dev/null; then
  ollama serve &>/dev/null &
  sleep 2
fi

# Start backend in background
cd "$SCRIPT_DIR/server" && node --watch index.js &
BACKEND_PID=$!

# Trap Ctrl+C to kill both
trap "kill $BACKEND_PID 2>/dev/null; exit 0" INT TERM

# Start frontend dev server (foreground)
cd "$SCRIPT_DIR/app" && npm run dev

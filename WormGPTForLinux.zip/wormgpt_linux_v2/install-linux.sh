#!/bin/bash
# ============================================================
#  WormGPT Enhanced — Universal Linux Installer v2
#  Supports: Pop!_OS · Kali Linux · Arch Linux · Ubuntu
#            Debian · Fedora · Manjaro · EndeavourOS · Mint
#            OpenSUSE · RHEL · CentOS Stream
# ============================================================
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

ok()   { echo -e "${GREEN}✅ $*${RESET}"; }
info() { echo -e "${CYAN}ℹ  $*${RESET}"; }
warn() { echo -e "${YELLOW}⚠  $*${RESET}"; }
err()  { echo -e "${RED}❌ $*${RESET}"; exit 1; }
step() { echo -e "\n${BOLD}${CYAN}▶ $*${RESET}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${BOLD}"
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║       WormGPT Enhanced — Linux Setup v2      ║"
echo "  ║  Pop!_OS · Kali · Arch · Ubuntu · Fedora     ║"
echo "  ╚══════════════════════════════════════════════╝"
echo -e "${RESET}"

# ── 1. Detect distro & package manager ───────────────────────
step "Detecting system"
if   command -v pacman  &>/dev/null; then PKG_MGR="pacman";  DISTRO_TYPE="arch"
elif command -v apt-get &>/dev/null; then PKG_MGR="apt";     DISTRO_TYPE="debian"
elif command -v dnf     &>/dev/null; then PKG_MGR="dnf";     DISTRO_TYPE="fedora"
elif command -v zypper  &>/dev/null; then PKG_MGR="zypper";  DISTRO_TYPE="opensuse"
else warn "Unknown package manager"; PKG_MGR="unknown"; DISTRO_TYPE="unknown"; fi

if [ -f /etc/os-release ]; then
  . /etc/os-release
  info "Distro: ${PRETTY_NAME:-$ID}"
fi
info "Package manager: $PKG_MGR"

# ── 2. Install curl / git if missing ─────────────────────────
step "Checking basic tools"
MISSING=()
command -v curl &>/dev/null || MISSING+=(curl)
command -v git  &>/dev/null || MISSING+=(git)

if [ ${#MISSING[@]} -gt 0 ]; then
  info "Installing: ${MISSING[*]}"
  case "$DISTRO_TYPE" in
    arch)     sudo pacman -Sy --noconfirm "${MISSING[@]}" ;;
    debian)   sudo apt-get update -qq && sudo apt-get install -y "${MISSING[@]}" ;;
    fedora)   sudo dnf install -y "${MISSING[@]}" ;;
    opensuse) sudo zypper install -y "${MISSING[@]}" ;;
    *)        warn "Please install: ${MISSING[*]}" ;;
  esac
fi
ok "curl and git present"

# ── 3. Install Node.js 20 LTS ─────────────────────────────────
step "Checking Node.js"
NEED_NODE=false
if command -v node &>/dev/null; then
  # Use node itself for reliable version detection (works on all distros)
  NODE_MAJOR=$(node -e "console.log(parseInt(process.versions.node.split('.')[0]))" 2>/dev/null || echo "0")
  if [ "$NODE_MAJOR" -ge 18 ]; then
    ok "Node.js $(node -v) — OK"
  else
    warn "Node.js $(node -v) is too old (need 18+)"
    NEED_NODE=true
  fi
else
  info "Node.js not found"
  NEED_NODE=true
fi

if [ "$NEED_NODE" = true ]; then
  info "Installing Node.js 20 LTS..."
  case "$DISTRO_TYPE" in
    arch)
      sudo pacman -Sy --noconfirm nodejs npm
      ;;
    debian)
      curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - 2>/dev/null
      sudo apt-get install -y nodejs
      ;;
    fedora)
      sudo dnf module reset nodejs -y 2>/dev/null || true
      sudo dnf install -y nodejs npm
      ;;
    opensuse)
      sudo zypper install -y nodejs20 npm20
      ;;
    *)
      warn "Cannot auto-install Node.js for your distro."
      echo "  Install Node.js 18+ from: https://nodejs.org"
      read -rp "Press Enter once installed, or Ctrl+C to abort..."
      ;;
  esac
  ok "Node.js $(node -v)"
fi

# Verify npm is available
if ! command -v npm &>/dev/null; then
  err "npm not found after Node.js install — try reinstalling Node.js"
fi
ok "npm $(npm -v)"

# ── 4. Install Ollama ─────────────────────────────────────────
step "Checking Ollama"
if command -v ollama &>/dev/null; then
  ok "Ollama already installed"
else
  info "Installing Ollama..."
  curl -fsSL https://ollama.ai/install.sh | sh
  ok "Ollama installed"
fi

# ── 5. Start Ollama & pull model ──────────────────────────────
step "Starting Ollama"
if ! pgrep -x "ollama" &>/dev/null; then
  ollama serve &>/dev/null &
  OLLAMA_BG_PID=$!
  echo -n "   Waiting for Ollama to be ready"
  for i in $(seq 1 20); do
    if curl -sf http://localhost:11434/api/tags &>/dev/null; then
      echo -e " ${GREEN}✅${RESET}"
      break
    fi
    echo -n "."
    sleep 1
  done
  if ! curl -sf http://localhost:11434/api/tags &>/dev/null; then
    warn "Ollama didn't start in time — you may need to pull the model manually"
    echo "  Run: ollama pull godmoded/llama3-lexi-uncensored"
  fi
else
  ok "Ollama already running"
fi

# Pull the default model
info "Pulling model: godmoded/llama3-lexi-uncensored"
info "(This may take several minutes on first run — ~5GB download)"
ollama pull godmoded/llama3-lexi-uncensored \
  && ok "Model ready" \
  || warn "Model pull failed — run manually later: ollama pull godmoded/llama3-lexi-uncensored"

# ── 6. Install frontend npm dependencies ──────────────────────
step "Installing frontend dependencies"
cd "$SCRIPT_DIR/app"
npm install
ok "Frontend deps installed"

# ── 7. Build frontend ─────────────────────────────────────────
step "Building frontend"
npm run build
if [ ! -d "$SCRIPT_DIR/app/dist" ]; then
  err "Build failed — dist directory not created. Check errors above."
fi
ok "Frontend built → app/dist/"

# ── 8. Install server dependencies ────────────────────────────
step "Installing server dependencies"
cd "$SCRIPT_DIR/server"
npm install
ok "Server deps installed"

cd "$SCRIPT_DIR"

# ── 9. Create systemd user service ────────────────────────────
step "Creating systemd service"
if command -v systemctl &>/dev/null; then
  mkdir -p ~/.config/systemd/user
  cat > ~/.config/systemd/user/wormgpt.service << SVCEOF
[Unit]
Description=WormGPT Enhanced — Local AI Chat
After=network.target

[Service]
Type=simple
WorkingDirectory=${SCRIPT_DIR}/server
ExecStartPre=/bin/bash -c 'command -v ollama && (pgrep -x ollama || (ollama serve &>/dev/null &)) && sleep 2 || true'
ExecStart=$(command -v node) ${SCRIPT_DIR}/server/index.js
Restart=on-failure
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=default.target
SVCEOF
  systemctl --user daemon-reload 2>/dev/null || true
  ok "Systemd service created (wormgpt.service)"
else
  info "systemctl not found — skipping systemd service"
fi

# ── 10. Create desktop .desktop entry ────────────────────────
step "Creating desktop launcher"
DESKTOP_DIR="$HOME/.local/share/applications"
mkdir -p "$DESKTOP_DIR"

# Find a suitable icon
ICON_PATH=""
for candidate in \
  "$SCRIPT_DIR/app/public/wormgpt-logo.jpg" \
  "/usr/share/pixmaps/firefox.png" \
  "/usr/share/pixmaps/chromium.png" \
  "/usr/share/icons/hicolor/48x48/apps/firefox.png"; do
  if [ -f "$candidate" ]; then ICON_PATH="$candidate"; break; fi
done

cat > "$DESKTOP_DIR/wormgpt-enhanced.desktop" << DESKEOF
[Desktop Entry]
Version=1.0
Name=WormGPT Enhanced
GenericName=AI Chat
Comment=Local AI Chat Interface powered by Ollama
Exec=bash -c '"${SCRIPT_DIR}/launch.sh"'
Icon=${ICON_PATH}
Terminal=false
Type=Application
Categories=Network;Chat;Development;Utility;
Keywords=AI;LLM;Ollama;Chat;GPT;
StartupNotify=true
StartupWMClass=WormGPT
DESKEOF

chmod +x "$DESKTOP_DIR/wormgpt-enhanced.desktop"
update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
ok "Desktop launcher → $DESKTOP_DIR/wormgpt-enhanced.desktop"

# ── 11. Create run-electron.sh (optional native window) ───────
cat > "$SCRIPT_DIR/run-electron.sh" << 'EEOF'
#!/bin/bash
# Run WormGPT as a native desktop window using Electron (optional)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v electron &>/dev/null; then
  echo "Installing electron globally (requires npm)..."
  sudo npm install -g electron --unsafe-perm 2>/dev/null \
    || npm install -g electron
fi

# Start backend
bash "$SCRIPT_DIR/start.sh" &
SERVER_PID=$!

# Wait for server
for i in $(seq 1 20); do
  curl -sf http://localhost:3001 &>/dev/null && break
  sleep 1
done

# Launch Electron window
electron \
  --app=http://localhost:3001 \
  --window-size=1280,800 \
  --title="WormGPT Enhanced" \
  --no-sandbox \
  2>/dev/null \
  || xdg-open http://localhost:3001

wait $SERVER_PID
EEOF
chmod +x "$SCRIPT_DIR/run-electron.sh"

# ── Done! ──────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}"
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║       ✅  Installation Complete!                 ║"
echo "  ╠══════════════════════════════════════════════════╣"
echo "  ║                                                  ║"
echo "  ║  ▶  Quick launch:   ./launch.sh                  ║"
echo "  ║  ▶  Server only:    ./start.sh                   ║"
echo "  ║  ▶  Dev mode:       ./dev.sh                     ║"
echo "  ║  ▶  Desktop app:    ./run-electron.sh            ║"
echo "  ║                                                  ║"
echo "  ║  Systemd (auto-start on login):                  ║"
echo "  ║    systemctl --user enable wormgpt               ║"
echo "  ║    systemctl --user start wormgpt                ║"
echo "  ║                                                  ║"
echo "  ║  URL:      http://localhost:3001                  ║"
echo "  ║  Password: Realnojokepplwazy1234                 ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo -e "${RESET}"

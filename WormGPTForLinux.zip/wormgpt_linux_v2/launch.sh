#!/bin/bash
# WormGPT Enhanced — Launch (server + browser)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GREEN='\033[0;32m'; CYAN='\033[0;36m'; RESET='\033[0m'

# Start the server in background
bash "$SCRIPT_DIR/start.sh" &
SERVER_PID=$!

# Wait for server to accept connections (up to 30s)
echo -e "${CYAN}⏳ Waiting for server to be ready...${RESET}"
for i in $(seq 1 30); do
  if curl -sf http://localhost:3001 &>/dev/null; then
    echo -e "${GREEN}✅ Server ready!${RESET}"
    break
  fi
  sleep 1
done

# Open browser
echo -e "${CYAN}🌐 Opening browser...${RESET}"
if command -v xdg-open &>/dev/null; then
  xdg-open http://localhost:3001 &
elif command -v firefox &>/dev/null; then
  firefox http://localhost:3001 &
elif command -v chromium-browser &>/dev/null; then
  chromium-browser http://localhost:3001 &
elif command -v chromium &>/dev/null; then
  chromium http://localhost:3001 &
elif command -v google-chrome &>/dev/null; then
  google-chrome http://localhost:3001 &
fi

# Keep server alive
wait $SERVER_PID

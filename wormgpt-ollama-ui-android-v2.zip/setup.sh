#!/data/data/com.termux/files/usr/bin/bash

# WormGPT Ollama UI - Termux One-Command Setup
# This script is designed to be run directly from a URL or locally.

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}--------------------------------------------------${NC}"
echo -e "${YELLOW}   WormGPT Ollama UI - One-Command Setup${NC}"
echo -e "${YELLOW}--------------------------------------------------${NC}"

# Check if we are in Termux
if [ ! -d "/data/data/com.termux/files/usr/bin" ]; then
    echo -e "${RED}Error: This script is designed for Termux on Android.${NC}"
    exit 1
fi

# If the script is run from within the project folder
if [ -f "install-termux.sh" ]; then
    chmod +x install-termux.sh
    ./install-termux.sh
else
    # If the user doesn't have the project yet, they should download the zip or clone.
    # Since I'm providing a zip, I'll assume they've extracted it.
    echo -e "${RED}Error: install-termux.sh not found in current directory.${NC}"
    echo -e "${YELLOW}Please ensure you have extracted the project and are running this script from the project folder.${NC}"
    exit 1
fi

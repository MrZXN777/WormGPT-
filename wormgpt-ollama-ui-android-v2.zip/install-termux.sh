#!/data/data/com.termux/files/usr/bin/bash

# WormGPT Ollama UI - Robust Termux One-Command Installer
# This script handles everything: dependencies, Ollama, and the LLM model.

set -e

# Colors for better output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}--------------------------------------------------${NC}"
echo -e "${YELLOW}   WormGPT Ollama UI - Termux Installer${NC}"
echo -e "${YELLOW}--------------------------------------------------${NC}"

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# 1. Update and install system dependencies
echo -e "${GREEN}[1/6] Updating system and installing dependencies...${NC}"
pkg update -y
pkg upgrade -y
pkg install -y nodejs-lts git curl wget pnpm procps

# 2. Install Ollama in Termux
echo -e "${GREEN}[2/6] Installing Ollama...${NC}"
if ! command_exists ollama; then
    echo -e "${YELLOW}Ollama not found. Installing...${NC}"
    # Official Ollama install script
    curl -fsSL https://ollama.com/install.sh | sh
else
    echo -e "${YELLOW}Ollama is already installed.${NC}"
fi

# 3. Install project dependencies
echo -e "${GREEN}[3/6] Installing project dependencies with pnpm...${NC}"
if [ -f "package.json" ]; then
    pnpm install
else
    echo -e "${RED}Error: package.json not found. Please run this script from the project root.${NC}"
    exit 1
fi

# 4. Setup Ollama Service and Model
echo -e "${GREEN}[4/6] Setting up Ollama service and pulling model...${NC}"

# Kill any existing ollama processes to start fresh
pkill -f "ollama serve" || true

# Start Ollama in background
echo -e "${YELLOW}Starting Ollama server in background...${NC}"
ollama serve > /dev/null 2>&1 &

# Wait for Ollama to be ready
echo -e "${YELLOW}Waiting for Ollama to start...${NC}"
MAX_RETRIES=30
RETRY_COUNT=0
while ! curl -s http://localhost:11434/api/tags > /dev/null; do
    sleep 2
    RETRY_COUNT=$((RETRY_COUNT+1))
    if [ $RETRY_COUNT -ge $MAX_RETRIES ]; then
        echo -e "${RED}Error: Ollama failed to start after 60 seconds.${NC}"
        exit 1
    fi
done
echo -e "${GREEN}Ollama is ready!${NC}"

# Pull the model
MODEL_NAME="godmoded/llama3-lexi-uncensored"
echo -e "${YELLOW}Pulling model: ${MODEL_NAME}...${NC}"
echo -e "${YELLOW}This may take several minutes depending on your internet speed.${NC}"
ollama pull "$MODEL_NAME"

# 5. Create a start script for convenience
echo -e "${GREEN}[5/6] Creating start script...${NC}"
cat <<EOF > start.sh
#!/data/data/com.termux/files/usr/bin/bash
# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Start Ollama if not running
if ! pgrep -f "ollama serve" > /dev/null; then
    echo -e "\${YELLOW}Starting Ollama server...\${NC}"
    ollama serve > /dev/null 2>&1 &
    sleep 5
fi

echo -e "\${GREEN}Starting WormGPT UI...\${NC}"
pnpm dev
EOF
chmod +x start.sh

# 6. Final Instructions
echo -e "${YELLOW}--------------------------------------------------${NC}"
echo -e "${GREEN}   Installation Complete!${NC}"
echo -e "${YELLOW}--------------------------------------------------${NC}"
echo -e "To start the application, run:"
echo -e "  ${GREEN}./start.sh${NC}"
echo ""
echo -e "The UI will be available at: ${GREEN}http://localhost:3000${NC}"
echo -e "Password: ${GREEN}Realnojokepplwazy1234${NC}"
echo -e "${YELLOW}--------------------------------------------------${NC}"

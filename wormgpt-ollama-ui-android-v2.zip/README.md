# WormGPT - Local LLM Interface

A professional WebUI for local Large Language Models using Ollama, created by **MRZXN**.

## Features

- 🔐 Password-protected access
- 💬 ChatGPT-style interface
- 🤖 Ollama integration with auto-connect
- 📊 Context Window Visualizer
- 🔄 Multi-Model Consensus Mode
- ⏱️ Conversation Timeline Replay
- 🎤 Voice input & Text-to-speech
- 📁 Export/Import conversations
- 🎨 Dark/Light theme
- And 60+ more features!

## Prerequisites

- Node.js 18+ installed
- Ollama installed and running on your system
- Recommended model: `godmoded/llama3-lexi-uncensored`

## Installation

### Option 1: Local Development

1. Extract the ZIP file
2. Open terminal in the project folder
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start development server:
   ```bash
   npm run dev
   ```
5. Open http://localhost:3000
6. Enter password: `Realnojokepplwazy1234`

### Option 2: Production Build

1. Extract the ZIP file
2. Open terminal in the project folder
3. Install dependencies:
   ```bash
   npm install
   ```
4. Build for production:
   ```bash
   npm run build
   ```
5. Start production server:
   ```bash
   npm start
   ```
6. Open http://localhost:3000

## Ollama Setup

1. Install Ollama from https://ollama.ai
2. Pull the recommended model:
   ```bash
   ollama pull godmoded/llama3-lexi-uncensored
   ```
3. Start Ollama (it runs automatically on http://localhost:11434)
4. The app will auto-connect on startup

## Usage

1. Enter password: `Realnojokepplwazy1234`
2. Wait for "Connected to Ollama" message
3. Start chatting!

## Settings

Click the gear icon to configure:
- Ollama URL (default: http://localhost:11434)
- Model selection
- Temperature (creativity)
- Theme (dark/light)
- And more...

## Advanced Features

### Context Window Visualizer
Click the graph icon to see real-time token usage and context health.

### Multi-Model Consensus
1. Go to Settings
2. Select 2+ models under "Consensus Mode Models"
3. Click the branch icon in header
4. Compare responses from multiple models

### Timeline Replay
Click the clock icon to replay conversations with timeline scrubbing.

## Troubleshooting

**Can't connect to Ollama?**
- Make sure Ollama is running: `ollama serve`
- Check if http://localhost:11434 is accessible
- Go to Settings and test connection

**Password not working?**
- Password is: `Realnojokepplwazy1234` (case-sensitive)

**Models not showing?**
- Pull models first: `ollama pull llama2`
- Restart the app

## Credits

**Created by MRZXN**

Visit [mrzxnportal.netlify.app](https://mrzxnportal.netlify.app) to request custom websites for anything.

## License

All rights reserved. This software is protected and cannot be modified or redistributed without permission.

// Voice input and Text-to-Speech utilities

export class VoiceService {
  private recognition: any = null;
  private synthesis: SpeechSynthesis | null = null;

  constructor() {
    // Initialize Speech Recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = false;
      this.recognition.interimResults = false;
      this.recognition.lang = 'en-US';
    }

    // Initialize Speech Synthesis
    if ('speechSynthesis' in window) {
      this.synthesis = window.speechSynthesis;
    }
  }

  // Voice Input (Speech-to-Text)
  isVoiceInputSupported(): boolean {
    return this.recognition !== null;
  }

  startListening(
    onResult: (transcript: string) => void,
    onError?: (error: string) => void
  ): void {
    if (!this.recognition) {
      onError?.("Voice input not supported");
      return;
    }

    this.recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      onResult(transcript);
    };

    this.recognition.onerror = (event: any) => {
      onError?.(event.error);
    };

    try {
      this.recognition.start();
    } catch (error) {
      onError?.("Failed to start voice input");
    }
  }

  stopListening(): void {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (error) {
        console.error("Failed to stop recognition:", error);
      }
    }
  }

  // Text-to-Speech
  isTTSSupported(): boolean {
    return this.synthesis !== null;
  }

  speak(
    text: string,
    options?: {
      rate?: number;
      pitch?: number;
      volume?: number;
      voice?: SpeechSynthesisVoice;
      onEnd?: () => void;
    }
  ): void {
    if (!this.synthesis) {
      console.error("Text-to-speech not supported");
      return;
    }

    // Cancel any ongoing speech
    this.synthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    
    if (options?.rate) utterance.rate = options.rate;
    if (options?.pitch) utterance.pitch = options.pitch;
    if (options?.volume) utterance.volume = options.volume;
    if (options?.voice) utterance.voice = options.voice;
    if (options?.onEnd) utterance.onend = options.onEnd;

    this.synthesis.speak(utterance);
  }

  stopSpeaking(): void {
    if (this.synthesis) {
      this.synthesis.cancel();
    }
  }

  getVoices(): SpeechSynthesisVoice[] {
    if (!this.synthesis) return [];
    return this.synthesis.getVoices();
  }

  isSpeaking(): boolean {
    return this.synthesis?.speaking || false;
  }
}

export const voiceService = new VoiceService();

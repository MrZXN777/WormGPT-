import type { Message, Conversation } from "./storage";

export interface TimelineEvent {
  id: string;
  type: "message" | "edit" | "regenerate" | "branch";
  timestamp: Date;
  messageId?: string;
  content?: string;
  role?: "user" | "assistant";
}

export interface TimelineState {
  currentIndex: number;
  events: TimelineEvent[];
  playbackSpeed: number; // 1x, 2x, 4x
  isPlaying: boolean;
}

export class TimelineService {
  static buildTimeline(conversation: Conversation): TimelineEvent[] {
    const events: TimelineEvent[] = [];
    
    conversation.messages.forEach((message) => {
      events.push({
        id: `msg-${message.id}`,
        type: "message",
        timestamp: message.timestamp,
        messageId: message.id,
        content: message.content,
        role: message.role === "system" ? "assistant" : message.role
      });
    });
    
    // Sort by timestamp
    events.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    
    return events;
  }

  static getMessagesUpToIndex(
    events: TimelineEvent[],
    index: number
  ): Message[] {
    const messages: Message[] = [];
    
    for (let i = 0; i <= index && i < events.length; i++) {
      const event = events[i];
      if (event.type === "message" && event.content && event.role) {
        messages.push({
          id: event.messageId || event.id,
          role: event.role,
          content: event.content,
          timestamp: event.timestamp
        });
      }
    }
    
    return messages;
  }

  static calculateHeatmap(conversation: Conversation): Map<string, number> {
    const heatmap = new Map<string, number>();
    
    // Count back-and-forth between consecutive messages
    for (let i = 1; i < conversation.messages.length; i++) {
      const prev = conversation.messages[i - 1];
      const curr = conversation.messages[i];
      
      // If roles alternate, it's a back-and-forth
      if (prev.role !== curr.role) {
        const key = `${prev.id}-${curr.id}`;
        heatmap.set(key, (heatmap.get(key) || 0) + 1);
      }
    }
    
    return heatmap;
  }

  static findBranchPoints(conversation: Conversation): string[] {
    // Identify messages where user could branch off
    const branchPoints: string[] = [];
    
    conversation.messages.forEach((message, index) => {
      // Any user message followed by assistant response is a potential branch point
      if (
        message.role === "user" &&
        index < conversation.messages.length - 1 &&
        conversation.messages[index + 1].role === "assistant"
      ) {
        branchPoints.push(message.id);
      }
    });
    
    return branchPoints;
  }

  static getTimelineStats(events: TimelineEvent[]): {
    totalDuration: number;
    averageResponseTime: number;
    messageCount: number;
  } {
    if (events.length === 0) {
      return { totalDuration: 0, averageResponseTime: 0, messageCount: 0 };
    }
    
    const firstEvent = events[0];
    const lastEvent = events[events.length - 1];
    const totalDuration = lastEvent.timestamp.getTime() - firstEvent.timestamp.getTime();
    
    // Calculate average response time (time between user and assistant messages)
    const responseTimes: number[] = [];
    for (let i = 1; i < events.length; i++) {
      const prev = events[i - 1];
      const curr = events[i];
      
      if (prev.role === "user" && curr.role === "assistant") {
        const responseTime = curr.timestamp.getTime() - prev.timestamp.getTime();
        responseTimes.push(responseTime);
      }
    }
    
    const averageResponseTime = responseTimes.length > 0
      ? responseTimes.reduce((sum, time) => sum + time, 0) / responseTimes.length
      : 0;
    
    const messageCount = events.filter(e => e.type === "message").length;
    
    return {
      totalDuration,
      averageResponseTime,
      messageCount
    };
  }

  static exportTimeline(conversation: Conversation): string {
    const events = this.buildTimeline(conversation);
    const stats = this.getTimelineStats(events);
    
    let output = `# Timeline Export: ${conversation.title}\n\n`;
    output += `**Created:** ${conversation.createdAt.toLocaleString()}\n`;
    output += `**Duration:** ${(stats.totalDuration / 1000 / 60).toFixed(1)} minutes\n`;
    output += `**Messages:** ${stats.messageCount}\n`;
    output += `**Avg Response Time:** ${(stats.averageResponseTime / 1000).toFixed(1)}s\n\n`;
    output += `---\n\n`;
    
    events.forEach((event, index) => {
      const time = event.timestamp.toLocaleTimeString();
      output += `**[${index + 1}] ${time}** - ${event.role?.toUpperCase()}\n`;
      output += `${event.content}\n\n`;
    });
    
    return output;
  }

  static async playTimeline(
    events: TimelineEvent[],
    speed: number,
    onEvent: (event: TimelineEvent, index: number) => void,
    startIndex: number = 0
  ): Promise<void> {
    for (let i = startIndex; i < events.length; i++) {
      const event = events[i];
      onEvent(event, i);
      
      // Calculate delay based on actual time difference and playback speed
      if (i < events.length - 1) {
        const nextEvent = events[i + 1];
        const actualDelay = nextEvent.timestamp.getTime() - event.timestamp.getTime();
        const scaledDelay = actualDelay / speed;
        
        // Cap maximum delay at 2 seconds
        const delay = Math.min(scaledDelay, 2000);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
}

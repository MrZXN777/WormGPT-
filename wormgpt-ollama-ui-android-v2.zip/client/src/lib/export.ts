import type { Conversation } from "./storage";

export class ExportService {
  static printConversation(conversation: Conversation): void {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${conversation.title}</title>
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
              max-width: 800px;
              margin: 40px auto;
              padding: 20px;
              color: #333;
            }
            h1 {
              color: #dc2626;
              border-bottom: 2px solid #dc2626;
              padding-bottom: 10px;
            }
            .message {
              margin: 20px 0;
              padding: 15px;
              border-radius: 8px;
            }
            .user {
              background: #f3f4f6;
              margin-left: 40px;
            }
            .assistant {
              background: #fef2f2;
              margin-right: 40px;
            }
            .role {
              font-weight: bold;
              margin-bottom: 8px;
              color: #dc2626;
            }
            .timestamp {
              font-size: 12px;
              color: #6b7280;
              margin-top: 8px;
            }
            @media print {
              body { margin: 20px; }
            }
          </style>
        </head>
        <body>
          <h1>${conversation.title}</h1>
          <p style="color: #6b7280;">Created: ${conversation.createdAt.toLocaleString()}</p>
          ${conversation.messages.map(msg => `
            <div class="message ${msg.role}">
              <div class="role">${msg.role === 'user' ? 'You' : 'WormGPT'}</div>
              <div class="content">${msg.content.replace(/\n/g, '<br>')}</div>
              <div class="timestamp">${msg.timestamp.toLocaleString()}</div>
            </div>
          `).join('')}
        </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.focus();
    
    setTimeout(() => {
      printWindow.print();
    }, 250);
  }

  static async exportToPDF(conversation: Conversation): Promise<void> {
    // Use browser's print to PDF functionality
    this.printConversation(conversation);
  }

  static copyEntireConversation(conversation: Conversation): string {
    let text = `${conversation.title}\n${'='.repeat(conversation.title.length)}\n\n`;
    text += `Created: ${conversation.createdAt.toLocaleString()}\n\n`;
    
    conversation.messages.forEach((msg, index) => {
      text += `[${msg.role.toUpperCase()}] ${msg.timestamp.toLocaleString()}\n`;
      text += `${msg.content}\n\n`;
      if (index < conversation.messages.length - 1) {
        text += '---\n\n';
      }
    });
    
    return text;
  }
}

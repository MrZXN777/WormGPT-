import { ollamaService, type OllamaModel } from "./ollama";
import type { Message } from "./storage";

export interface ModelResponse {
  model: string;
  content: string;
  timestamp: Date;
  tokensPerSecond?: number;
  totalTime?: number;
}

export interface ConsensusAnalysis {
  agreements: string[];
  disagreements: string[];
  uniqueInsights: Map<string, string[]>;
  bestResponse?: string; // model name
  confidence: number; // 0-1
}

export class ConsensusService {
  static async queryMultipleModels(
    models: string[],
    messages: Message[],
    temperature: number = 0.7,
    onProgress?: (model: string, chunk: string) => void
  ): Promise<ModelResponse[]> {
    const responses: ModelResponse[] = [];
    
    // Query all models in parallel
    const promises = models.map(async (model) => {
      let fullContent = "";
      const startTime = Date.now();
      
      try {
        const ollamaMessages = messages.map(m => ({
          role: m.role as "user" | "assistant",
          content: m.content
        }));
        
        const stream = ollamaService.streamChat(model, ollamaMessages, temperature, (chunk) => {
          fullContent += chunk;
          onProgress?.(model, chunk);
        });
        
        for await (const chunk of stream) {
          // Chunks are already handled by onToken callback
        }
        
        const totalTime = Date.now() - startTime;
        const tokens = this.estimateTokens(fullContent);
        
        return {
          model,
          content: fullContent,
          timestamp: new Date(),
          tokensPerSecond: tokens / (totalTime / 1000),
          totalTime
        };
      } catch (error) {
        console.error(`Error querying model ${model}:`, error);
        return {
          model,
          content: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
          timestamp: new Date()
        };
      }
    });
    
    const results = await Promise.all(promises);
    return results;
  }

  static analyzeConsensus(responses: ModelResponse[]): ConsensusAnalysis {
    const agreements: string[] = [];
    const disagreements: string[] = [];
    const uniqueInsights = new Map<string, string[]>();
    
    // Extract key points from each response
    const responsePoints = responses.map(r => ({
      model: r.model,
      points: this.extractKeyPoints(r.content)
    }));
    
    // Find agreements (points mentioned by multiple models)
    const allPoints = responsePoints.flatMap(rp => rp.points);
    const pointCounts = new Map<string, number>();
    
    allPoints.forEach(point => {
      const normalized = point.toLowerCase().trim();
      pointCounts.set(normalized, (pointCounts.get(normalized) || 0) + 1);
    });
    
    // Points mentioned by 2+ models are agreements
    pointCounts.forEach((count, point) => {
      if (count >= 2 && point.length > 20) {
        agreements.push(point);
      }
    });
    
    // Find unique insights (points mentioned by only one model)
    responsePoints.forEach(rp => {
      const unique = rp.points.filter(point => {
        const normalized = point.toLowerCase().trim();
        return (pointCounts.get(normalized) || 0) === 1 && point.length > 20;
      });
      
      if (unique.length > 0) {
        uniqueInsights.set(rp.model, unique);
      }
    });
    
    // Find disagreements (contradicting statements)
    const contradictions = this.findContradictions(responsePoints);
    disagreements.push(...contradictions);
    
    // Calculate confidence based on agreement level
    const agreementRatio = agreements.length / Math.max(allPoints.length, 1);
    const confidence = Math.min(agreementRatio * 1.5, 1);
    
    // Determine best response (most comprehensive)
    const bestResponse = this.selectBestResponse(responses);
    
    return {
      agreements: agreements.slice(0, 10), // Top 10
      disagreements: disagreements.slice(0, 5), // Top 5
      uniqueInsights,
      bestResponse,
      confidence
    };
  }

  private static extractKeyPoints(text: string): string[] {
    // Split by sentences and filter meaningful ones
    const sentences = text
      .split(/[.!?]+/)
      .map(s => s.trim())
      .filter(s => s.length > 30 && s.length < 200);
    
    return sentences;
  }

  private static findContradictions(
    responsePoints: Array<{ model: string; points: string[] }>
  ): string[] {
    const contradictions: string[] = [];
    
    // Look for negation patterns
    const negationWords = ['not', 'no', 'never', 'cannot', 'isn\'t', 'aren\'t', 'won\'t'];
    
    for (let i = 0; i < responsePoints.length; i++) {
      for (let j = i + 1; j < responsePoints.length; j++) {
        const points1 = responsePoints[i].points;
        const points2 = responsePoints[j].points;
        
        points1.forEach(p1 => {
          points2.forEach(p2 => {
            // Check if one contains negation and they're about similar topics
            const hasNegation1 = negationWords.some(w => p1.toLowerCase().includes(w));
            const hasNegation2 = negationWords.some(w => p2.toLowerCase().includes(w));
            
            if (hasNegation1 !== hasNegation2) {
              const similarity = this.calculateSimilarity(p1, p2);
              if (similarity > 0.5) {
                contradictions.push(
                  `${responsePoints[i].model}: "${p1}" vs ${responsePoints[j].model}: "${p2}"`
                );
              }
            }
          });
        });
      }
    }
    
    return contradictions;
  }

  private static calculateSimilarity(text1: string, text2: string): number {
    const words1 = new Set(text1.toLowerCase().split(/\s+/));
    const words2 = new Set(text2.toLowerCase().split(/\s+/));
    
    const intersection = new Set(Array.from(words1).filter(w => words2.has(w)));
    const union = new Set([...Array.from(words1), ...Array.from(words2)]);
    
    return intersection.size / union.size;
  }

  private static selectBestResponse(responses: ModelResponse[]): string {
    // Score based on length, speed, and completeness
    let bestScore = -1;
    let bestModel = responses[0]?.model || "";
    
    responses.forEach(response => {
      const lengthScore = Math.min(response.content.length / 1000, 1);
      const speedScore = response.tokensPerSecond ? Math.min(response.tokensPerSecond / 50, 1) : 0.5;
      const completenessScore = response.content.includes("```") ? 0.2 : 0; // Bonus for code
      
      const score = lengthScore * 0.5 + speedScore * 0.3 + completenessScore;
      
      if (score > bestScore) {
        bestScore = score;
        bestModel = response.model;
      }
    });
    
    return bestModel;
  }

  private static estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }

  static mergeResponses(responses: ModelResponse[], analysis: ConsensusAnalysis): string {
    let merged = "# Consensus Summary\n\n";
    
    // Add agreements
    if (analysis.agreements.length > 0) {
      merged += "## Key Agreements\n\n";
      analysis.agreements.forEach((agreement, i) => {
        merged += `${i + 1}. ${agreement}\n`;
      });
      merged += "\n";
    }
    
    // Add unique insights
    if (analysis.uniqueInsights.size > 0) {
      merged += "## Unique Insights by Model\n\n";
      analysis.uniqueInsights.forEach((insights, model) => {
        merged += `### ${model}\n`;
        insights.forEach(insight => {
          merged += `- ${insight}\n`;
        });
        merged += "\n";
      });
    }
    
    // Add disagreements
    if (analysis.disagreements.length > 0) {
      merged += "## Disagreements\n\n";
      analysis.disagreements.forEach((disagreement, i) => {
        merged += `${i + 1}. ${disagreement}\n`;
      });
      merged += "\n";
    }
    
    // Add best response
    if (analysis.bestResponse) {
      const best = responses.find(r => r.model === analysis.bestResponse);
      if (best) {
        merged += `## Recommended Response (${analysis.bestResponse})\n\n`;
        merged += best.content;
      }
    }
    
    return merged;
  }
}

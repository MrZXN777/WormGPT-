/**
 * WormGPT Presentation Page
 * Design: Cyberpunk Terminal Aesthetic
 * Showcases the WormGPT Ollama UI project features and capabilities
 */

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  MessageSquare, 
  Shield, 
  Zap, 
  Lock, 
  Terminal, 
  Cpu,
  Database,
  Settings,
  ArrowRight,
  Github,
  Download,
  CheckCircle2
} from "lucide-react";
import { Link } from "wouter";

export default function Presentation() {
  const features = [
    {
      icon: Shield,
      title: "Complete Privacy",
      description: "All conversations run locally on your machine. Your data never leaves your computer, ensuring absolute privacy and security.",
    },
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Direct connection to Ollama with no network latency. Experience instant responses from your local LLM models.",
    },
    {
      icon: Lock,
      title: "No Restrictions",
      description: "Unfiltered, jailbroken chatbot experience. No ethical guidelines, no content restrictions, no limitations.",
    },
    {
      icon: Terminal,
      title: "Terminal Aesthetic",
      description: "Cyberpunk-inspired dark interface with monospace fonts, glowing effects, and scan-line animations.",
    },
    {
      icon: Cpu,
      title: "Multi-Model Support",
      description: "Works with any Ollama model including Llama 2, Mistral, CodeLlama, and custom fine-tuned models.",
    },
    {
      icon: Database,
      title: "Conversation History",
      description: "Persistent chat history with the ability to create, manage, and delete multiple conversation threads.",
    },
  ];

  const technicalSpecs = [
    { label: "Framework", value: "React 19 + TypeScript" },
    { label: "Styling", value: "Tailwind CSS 4" },
    { label: "UI Components", value: "shadcn/ui" },
    { label: "Backend", value: "Ollama API" },
    { label: "Deployment", value: "Static Web App" },
    { label: "Theme", value: "Cyberpunk Dark" },
  ];

  const capabilities = [
    "Real-time message streaming",
    "Markdown rendering with syntax highlighting",
    "Copy to clipboard functionality",
    "Keyboard shortcuts (Enter to send, Shift+Enter for new line)",
    "Connection status monitoring",
    "Configurable Ollama endpoint",
    "Model selection and configuration",
    "Responsive design for all screen sizes",
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <section className="relative border-b border-border bg-gradient-to-b from-background to-card">
        <div className="container mx-auto px-6 py-20">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <div className="flex-1 space-y-6">
              <div className="inline-flex items-center gap-3 bg-primary/10 border border-primary/30 px-4 py-2">
                <img
                  src="/images/wormgpt-logo.png"
                  alt="WormGPT Logo"
                  className="h-8 w-8 glow-red"
                />
                <span className="text-sm font-bold text-primary">WormGPT Ollama UI</span>
              </div>
              
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                <span className="text-primary">Unfiltered</span> Local LLM Interface
              </h1>
              
              <p className="text-xl text-muted-foreground leading-relaxed max-w-2xl">
                A powerful, privacy-focused web interface for interacting with local Large Language Models through Ollama. 
                No ethics. No restrictions. No limits.
              </p>

              <div className="flex flex-wrap gap-4">
                <Link href="/">
                  <Button className="bg-primary hover:bg-primary/90 text-primary-foreground glow-red px-8 py-6 text-lg">
                    Launch Application
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  className="border-primary/30 hover:border-primary hover:glow-red px-8 py-6 text-lg"
                  onClick={() => window.open('https://ollama.ai', '_blank')}
                >
                  <Download className="mr-2 h-5 w-5" />
                  Get Ollama
                </Button>
              </div>
            </div>

            <div className="flex-1">
              <div className="relative">
                <div className="absolute inset-0 bg-primary/20 blur-3xl glow-red-intense" />
                <img
                  src="/images/wormgpt-logo.png"
                  alt="WormGPT"
                  className="relative h-64 w-64 lg:h-96 lg:w-96 mx-auto glow-red-intense animate-pulse-slow"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-primary mb-4">Core Features</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Built for power users who demand complete control over their AI interactions
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="bg-card border-border hover:border-primary/30 transition-all hover:glow-red">
                <CardHeader>
                  <div className="h-12 w-12 rounded bg-primary/10 border border-primary/30 flex items-center justify-center mb-4 glow-red">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-muted-foreground">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section className="py-20 bg-card border-y border-border">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-primary mb-4">Technical Stack</h2>
              <p className="text-muted-foreground text-lg">
                Built with modern web technologies for optimal performance
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                {technicalSpecs.map((spec, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-background border border-border">
                    <span className="text-sm font-medium text-muted-foreground">{spec.label}</span>
                    <span className="text-sm font-bold text-primary">{spec.value}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-4">
                <h3 className="text-xl font-bold mb-4">Capabilities</h3>
                <div className="space-y-3">
                  {capabilities.map((capability, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-muted-foreground">{capability}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-primary mb-4">How It Works</h2>
              <p className="text-muted-foreground text-lg">
                Get started with WormGPT in three simple steps
              </p>
            </div>

            <div className="space-y-8">
              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 h-12 w-12 rounded bg-primary/10 border border-primary/30 flex items-center justify-center text-2xl font-bold text-primary glow-red">
                  1
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold mb-2">Install Ollama</h3>
                  <p className="text-muted-foreground">
                    Download and install Ollama on your local machine. Ollama provides the backend infrastructure 
                    for running large language models locally with optimized performance.
                  </p>
                  <code className="block mt-3 p-3 bg-card border border-border text-sm text-accent">
                    curl https://ollama.ai/install.sh | sh
                  </code>
                </div>
              </div>

              <Separator className="bg-border" />

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 h-12 w-12 rounded bg-primary/10 border border-primary/30 flex items-center justify-center text-2xl font-bold text-primary glow-red">
                  2
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold mb-2">Pull a Model</h3>
                  <p className="text-muted-foreground">
                    Download your preferred language model. Ollama supports various models including Llama 2, 
                    Mistral, CodeLlama, and many others. Choose based on your hardware capabilities.
                  </p>
                  <code className="block mt-3 p-3 bg-card border border-border text-sm text-accent">
                    ollama pull llama2
                  </code>
                </div>
              </div>

              <Separator className="bg-border" />

              <div className="flex gap-6 items-start">
                <div className="flex-shrink-0 h-12 w-12 rounded bg-primary/10 border border-primary/30 flex items-center justify-center text-2xl font-bold text-primary glow-red">
                  3
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold mb-2">Configure & Chat</h3>
                  <p className="text-muted-foreground">
                    Open WormGPT, configure your Ollama connection settings, select your model, and start chatting. 
                    All conversations are processed locally with complete privacy.
                  </p>
                  <Link href="/">
                    <Button className="mt-3 bg-primary hover:bg-primary/90 text-primary-foreground glow-red">
                      <Settings className="mr-2 h-4 w-4" />
                      Open Settings
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-card border-t border-border">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <img
              src="/images/wormgpt-logo.png"
              alt="WormGPT"
              className="h-24 w-24 mx-auto glow-red-intense"
            />
            <h2 className="text-4xl font-bold">
              Ready to Experience <span className="text-primary">Unfiltered AI</span>?
            </h2>
            <p className="text-xl text-muted-foreground">
              Take control of your AI interactions with complete privacy and no restrictions
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/">
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground glow-red px-8 py-6 text-lg">
                  Launch WormGPT
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-background py-8">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img
                src="/images/wormgpt-logo.png"
                alt="WormGPT"
                className="h-8 w-8"
              />
              <span className="text-sm text-muted-foreground">
                WormGPT © 2026 • No ethics. No restrictions. No limits.
              </span>
            </div>
            <div className="flex gap-4">
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary">
                Documentation
              </Button>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary">
                <Github className="h-4 w-4 mr-2" />
                GitHub
              </Button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

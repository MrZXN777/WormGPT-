import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";

export default function Login() {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const { login, isLoading } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(password);
    if (!success) {
      setError("Invalid password");
      setPassword("");
    }
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-6">
          <img
            src="/images/wormgpt-logo.png"
            alt="WormGPT"
            className="h-20 w-20 mx-auto rounded-full animate-pulse"
          />
          <div className="space-y-3">
            <h2 className="text-2xl font-semibold">Loading...</h2>
            <p className="text-muted-foreground">Setting up WormGPT</p>
            <div className="w-64 h-2 bg-muted rounded-full overflow-hidden mx-auto">
              <div className="h-full bg-primary animate-[loading_2s_ease-in-out_infinite]" style={{
                animation: "loading 2s ease-in-out infinite",
              }} />
            </div>
          </div>
        </div>
        <style>{`
          @keyframes loading {
            0% { width: 0%; }
            50% { width: 100%; }
            100% { width: 0%; }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div className="h-screen flex items-center justify-center bg-background">
      <div className="w-full max-w-md p-8 space-y-6">
        <div className="text-center space-y-4">
          <img
            src="/images/wormgpt-logo.png"
            alt="WormGPT"
            className="h-20 w-20 mx-auto rounded-full"
          />
          <div>
            <h1 className="text-3xl font-bold">WormGPT</h1>
            <p className="text-sm text-muted-foreground mt-2">
              Enter password to continue
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Input
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError("");
              }}
              placeholder="Enter password"
              className="bg-input text-center"
              autoFocus
            />
            {error && (
              <p className="text-sm text-destructive mt-2 text-center">{error}</p>
            )}
          </div>

          <Button
            type="submit"
            className="w-full bg-primary text-primary-foreground"
            disabled={!password}
          >
            Unlock
          </Button>
        </form>
      </div>
    </div>
  );
}

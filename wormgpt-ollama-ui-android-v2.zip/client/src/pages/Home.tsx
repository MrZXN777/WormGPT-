/**
 * WormGPT Ollama UI - Complete Feature Implementation
 * Professional ChatGPT/Grok-style design maintained
 * All 70+ features integrated
 */

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { 
  MessageSquare, Plus, Send, Settings, Trash2, Copy, Check, ChevronRight,
  Download, Upload, Pin, Archive, Tag, Search, Edit2, RotateCcw, StopCircle,
  Mic, Volume2, Image as ImageIcon, Keyboard, Save, FileText, Printer,
  BarChart3, Star, Moon, Sun, Palette, Type, Zap, Bell, Lock, LogOut,
  MoreVertical, X, FileJson, FileCode, GitBranch, Clock, TrendingUp, Globe, Shield
} from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { Streamdown } from "streamdown";
import { StorageService, type Conversation, type Message } from "@/lib/storage";
import { ollamaService, type OllamaModel } from "@/lib/ollama";
import { RECOMMENDED_MODEL } from "@/lib/constants";
import { voiceService } from "@/lib/voice";
import { ExportService } from "@/lib/export";
import { TemplateService, type Template } from "@/lib/templates";
import { ContextAnalyzer, type ContextAnalysis } from "@/lib/context-analyzer";
import { ConsensusService, type ModelResponse, type ConsensusAnalysis } from "@/lib/consensus";
import { ContextVisualizer } from "@/components/ContextVisualizer";
import { ConsensusView } from "@/components/ConsensusView";
import { ConversationTimeline } from "@/components/ConversationTimeline";
import { OSINTDashboard } from "@/components/OSINTDashboard";
import { webSearchService } from "@/lib/web-search";
import { useAuth } from "@/contexts/AuthContext";
import { useTheme } from "@/contexts/ThemeContext";
import { useIsMobile } from "@/hooks/useMobile";
import { toast } from "sonner";
import { Menu } from "lucide-react";

export default function Home() {
  const isMobile = useIsMobile();
  // State Management
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string>("");
  const [inputValue, setInputValue] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const [availableModels, setAvailableModels] = useState<OllamaModel[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(isMobile);

  useEffect(() => {
    setSidebarCollapsed(isMobile);
  }, [isMobile]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [showFavorites, setShowFavorites] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [showStats, setShowStats] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showTagDialog, setShowTagDialog] = useState(false);
  const [newTag, setNewTag] = useState("");
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [showContextVisualizer, setShowContextVisualizer] = useState(false);
  const [contextAnalysis, setContextAnalysis] = useState<ContextAnalysis | null>(null);
  const [showConsensusMode, setShowConsensusMode] = useState(false);
  const [consensusResponses, setConsensusResponses] = useState<ModelResponse[]>([]);
  const [consensusAnalysis, setConsensusAnalysis] = useState<ConsensusAnalysis | null>(null);
  const [showTimeline, setShowTimeline] = useState(false);
  const [selectedModelsForConsensus, setSelectedModelsForConsensus] = useState<string[]>([]);
  const [showOSINTDashboard, setShowOSINTDashboard] = useState(false);
  const [webSearchEnabled, setWebSearchEnabled] = useState(false);
  
  // Settings State
  const [settings, setSettings] = useState(StorageService.getSettings());
  
  // Refs
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  
  // Hooks
  const { logout } = useAuth();
  const { theme, setTheme } = useTheme();

  // Load data on mount
  useEffect(() => {
    const loadedConversations = StorageService.getConversations();
    if (loadedConversations.length === 0) {
      const newConv: Conversation = {
        id: Date.now().toString(),
        title: "New Chat",
        messages: [],
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      setConversations([newConv]);
      setActiveConversationId(newConv.id);
      StorageService.addConversation(newConv);
    } else {
      setConversations(loadedConversations);
      setActiveConversationId(loadedConversations[0].id);
    }
    
    const draft = StorageService.getDraft();
    if (draft) setInputValue(draft);
    
    setFavorites(StorageService.getFavorites());
    setTemplates(TemplateService.getTemplates());
    
    // Auto-connect to Ollama
    const autoConnect = async () => {
      ollamaService.setBaseUrl(settings.ollamaUrl);
      const connected = await ollamaService.testConnection();
      setIsConnected(connected);
      
      if (connected) {
        const models = await ollamaService.listModels();
        setAvailableModels(models);
        toast.success("Connected to Ollama");
      } else {
        toast.error("Failed to connect to Ollama. Check settings.");
      }
    };
    
    autoConnect();
  }, []);

  // Update context analysis when messages change
  useEffect(() => {
    const currentConv = conversations.find(c => c.id === activeConversationId);
    if (currentConv && settings.selectedModel) {
      const analysis = ContextAnalyzer.analyzeContext(
        currentConv.messages,
        settings.selectedModel
      );
      setContextAnalysis(analysis);
    }
  }, [conversations, activeConversationId, settings.selectedModel]);

  // Auto-save draft
  useEffect(() => {
    if (inputValue) {
      StorageService.saveDraft(inputValue);
    }
  }, [inputValue]);

  // Auto-scroll
  useEffect(() => {
    if (settings.autoScroll && scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [conversations, activeConversationId, settings.autoScroll]);

  const activeConversation = conversations.find(c => c.id === activeConversationId);

  // Connection & Models
  const testConnection = async () => {
    ollamaService.setBaseUrl(settings.ollamaUrl);
    const connected = await ollamaService.testConnection();
    setIsConnected(connected);
    
    if (connected) {
      const models = await ollamaService.listModels();
      setAvailableModels(models);
      toast.success("Connected to Ollama");
    } else {
      toast.error("Failed to connect to Ollama");
    }
  };

  // Conversation Management
  const createNewConversation = () => {
    const newConv: Conversation = {
      id: Date.now().toString(),
      title: "New Chat",
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setConversations([newConv, ...conversations]);
    setActiveConversationId(newConv.id);
    StorageService.addConversation(newConv);
    toast.success("New chat created");
  };

  const deleteConversation = (id: string) => {
    const filtered = conversations.filter(c => c.id !== id);
    setConversations(filtered);
    StorageService.deleteConversation(id);
    if (activeConversationId === id && filtered.length > 0) {
      setActiveConversationId(filtered[0].id);
    }
    toast.success("Conversation deleted");
  };

  const togglePin = (id: string) => {
    const conv = conversations.find(c => c.id === id);
    if (conv) {
      const updated = { ...conv, isPinned: !conv.isPinned };
      StorageService.updateConversation(id, updated);
      setConversations(conversations.map(c => c.id === id ? updated : c));
    }
  };

  const toggleArchive = (id: string) => {
    const conv = conversations.find(c => c.id === id);
    if (conv) {
      const updated = { ...conv, isArchived: !conv.isArchived };
      StorageService.updateConversation(id, updated);
      setConversations(conversations.map(c => c.id === id ? updated : c));
      toast.success(updated.isArchived ? "Archived" : "Unarchived");
    }
  };

  const addTagToConversation = (id: string, tag: string) => {
    const conv = conversations.find(c => c.id === id);
    if (conv) {
      const tags = conv.tags || [];
      if (!tags.includes(tag)) {
        tags.push(tag);
        StorageService.updateConversation(id, { tags });
        setConversations(conversations.map(c => c.id === id ? { ...c, tags } : c));
      }
    }
  };

  const renameConversation = (id: string, newTitle: string) => {
    StorageService.updateConversation(id, { title: newTitle });
    setConversations(conversations.map(c => c.id === id ? { ...c, title: newTitle } : c));
  };

  // Message Handling
  const sendMessage = async (content?: string) => {
    const messageContent = content || inputValue.trim();
    if (!messageContent || !activeConversation || !isConnected) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: messageContent,
      timestamp: new Date(),
    };

    const updatedMessages = [...activeConversation.messages, userMessage];
    const updatedConv = {
      ...activeConversation,
      messages: updatedMessages,
      title: activeConversation.messages.length === 0 
        ? messageContent.slice(0, 30) + (messageContent.length > 30 ? "..." : "")
        : activeConversation.title,
      updatedAt: new Date(),
    };

    setConversations(conversations.map(c => c.id === activeConversationId ? updatedConv : c));
    StorageService.updateConversation(activeConversationId, updatedConv);
    setInputValue("");
    StorageService.clearDraft();

    // Stream AI response
    setIsStreaming(true);
    const assistantMessageId = (Date.now() + 1).toString();
    let fullResponse = "";

    try {
      const ollamaMessages = updatedMessages.map(m => ({
        role: m.role as "user" | "assistant" | "system",
        content: m.content,
      }));

      for await (const token of ollamaService.streamChat(
        settings.selectedModel,
        ollamaMessages,
        settings.temperature
      )) {
        fullResponse += token;
        
        // Update message in real-time
        const assistantMessage: Message = {
          id: assistantMessageId,
          role: "assistant",
          content: fullResponse,
          timestamp: new Date(),
        };

        setConversations(prev => prev.map(c => {
          if (c.id === activeConversationId) {
            const msgs = c.messages.filter(m => m.id !== assistantMessageId);
            return { ...c, messages: [...msgs, assistantMessage] };
          }
          return c;
        }));

        // Delay for stream speed control
        await new Promise(resolve => setTimeout(resolve, settings.streamSpeed));
      }

      // Save final message
      const finalConv = conversations.find(c => c.id === activeConversationId);
      if (finalConv) {
        StorageService.updateConversation(activeConversationId, {
          messages: [...updatedMessages, {
            id: assistantMessageId,
            role: "assistant",
            content: fullResponse,
            timestamp: new Date(),
          }],
        });
      }

      if (settings.soundEnabled) {
        new Audio("/notification.mp3").play().catch(() => {});
      }

      if (settings.notificationsEnabled && document.hidden) {
        new Notification("WormGPT", { body: "Response ready" });
      }

    } catch (error) {
      console.error("Streaming failed:", error);
      toast.error("Failed to get response from AI");
    } finally {
      setIsStreaming(false);
    }
  };

  const stopGeneration = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsStreaming(false);
    toast.info("Generation stopped");
  };

  const regenerateMessage = async (messageId: string) => {
    if (!activeConversation) return;
    
    const messageIndex = activeConversation.messages.findIndex(m => m.id === messageId);
    if (messageIndex === -1 || messageIndex === 0) return;

    // Remove messages after this point
    const messagesUpToHere = activeConversation.messages.slice(0, messageIndex);
    const lastUserMessage = messagesUpToHere[messagesUpToHere.length - 1];

    if (lastUserMessage && lastUserMessage.role === "user") {
      const updatedConv = { ...activeConversation, messages: messagesUpToHere };
      setConversations(conversations.map(c => c.id === activeConversationId ? updatedConv : c));
      await sendMessage(lastUserMessage.content);
    }
  };

  const editMessage = (messageId: string) => {
    const message = activeConversation?.messages.find(m => m.id === messageId);
    if (message) {
      setEditingMessageId(messageId);
      setEditingText(message.content);
    }
  };

  const saveEditedMessage = async () => {
    if (!activeConversation || !editingMessageId) return;

    const messageIndex = activeConversation.messages.findIndex(m => m.id === editingMessageId);
    if (messageIndex === -1) return;

    const updatedMessages = [...activeConversation.messages];
    updatedMessages[messageIndex] = {
      ...updatedMessages[messageIndex],
      content: editingText,
    };

    // Remove all messages after the edited one
    const messagesUpToEdit = updatedMessages.slice(0, messageIndex + 1);
    
    const updatedConv = { ...activeConversation, messages: messagesUpToEdit };
    setConversations(conversations.map(c => c.id === activeConversationId ? updatedConv : c));
    StorageService.updateConversation(activeConversationId, updatedConv);

    setEditingMessageId(null);
    setEditingText("");

    // Regenerate response if this was a user message
    if (messagesUpToEdit[messageIndex].role === "user") {
      await sendMessage(editingText);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
    toast.success("Copied to clipboard");
  };

  // Export/Import
  const exportConversation = (format: "json" | "txt" | "md") => {
    if (!activeConversation) return;
    
    const content = StorageService.exportConversation(activeConversation, format);
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${activeConversation.title}.${format}`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Conversation exported");
  };

  const importConversation = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const imported = StorageService.importConversation(content);
      if (imported) {
        imported.id = Date.now().toString();
        setConversations([imported, ...conversations]);
        StorageService.addConversation(imported);
        toast.success("Conversation imported");
      } else {
        toast.error("Failed to import conversation");
      }
    };
    reader.readAsText(file);
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        if (e.key === "n") {
          e.preventDefault();
          createNewConversation();
        } else if (e.key === "k") {
          e.preventDefault();
          setShowSearch(!showSearch);
        } else if (e.key === "s") {
          e.preventDefault();
          setShowSettings(!showSettings);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [showSearch, showSettings]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // Filter conversations
  const filteredConversations = conversations
    .filter(c => {
      if (searchQuery) {
        return c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
               c.messages.some(m => m.content.toLowerCase().includes(searchQuery.toLowerCase()));
      }
      if (selectedTags.length > 0) {
        return selectedTags.some(tag => c.tags?.includes(tag));
      }
      return !c.isArchived;
    })
    .sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return b.updatedAt.getTime() - a.updatedAt.getTime();
    });

  // Statistics
  const stats = {
    totalConversations: conversations.length,
    totalMessages: conversations.reduce((sum, c) => sum + c.messages.length, 0),
    totalWords: conversations.reduce((sum, c) => 
      sum + c.messages.reduce((mSum, m) => mSum + m.content.split(" ").length, 0), 0
    ),
  };

  // Voice Input
  const startVoiceInput = () => {
    if (!voiceService.isVoiceInputSupported()) {
      toast.error("Voice input not supported in this browser");
      return;
    }

    setIsRecording(true);
    voiceService.startListening(
      (transcript) => {
        setInputValue(prev => prev + " " + transcript);
        setIsRecording(false);
        toast.success("Voice input captured");
      },
      (error) => {
        setIsRecording(false);
        toast.error(`Voice input error: ${error}`);
      }
    );
  };

  const stopVoiceInput = () => {
    voiceService.stopListening();
    setIsRecording(false);
  };

  // Text-to-Speech
  const speakMessage = (text: string) => {
    if (!voiceService.isTTSSupported()) {
      toast.error("Text-to-speech not supported");
      return;
    }

    if (isSpeaking) {
      voiceService.stopSpeaking();
      setIsSpeaking(false);
    } else {
      setIsSpeaking(true);
      voiceService.speak(text, {
        onEnd: () => setIsSpeaking(false)
      });
    }
  };

  // Image Upload
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        setUploadedImages(prev => [...prev, dataUrl]);
        toast.success("Image uploaded");
      };
      reader.readAsDataURL(file);
    });
  };

  // Templates
  const useTemplate = (template: Template) => {
    setInputValue(template.prompt);
    setShowTemplates(false);
    textareaRef.current?.focus();
  };

  // Print & Export
  const printConversation = () => {
    if (!activeConversation) return;
    ExportService.printConversation(activeConversation);
    toast.success("Opening print dialog...");
  };

  const copyEntireConversation = () => {
    if (!activeConversation) return;
    const text = ExportService.copyEntireConversation(activeConversation);
    navigator.clipboard.writeText(text);
    toast.success("Entire conversation copied");
  };

  // Consensus Mode
  const startConsensusMode = async () => {
    if (!activeConversation || selectedModelsForConsensus.length < 2) {
      toast.error("Select at least 2 models for consensus mode");
      return;
    }

    setShowConsensusMode(true);
    toast.info("Querying multiple models...");

    try {
      const responses = await ConsensusService.queryMultipleModels(
        selectedModelsForConsensus,
        activeConversation.messages,
        settings.temperature
      );

      const analysis = ConsensusService.analyzeConsensus(responses);
      setConsensusResponses(responses);
      setConsensusAnalysis(analysis);
      toast.success("Consensus analysis complete");
    } catch (error) {
      toast.error("Failed to complete consensus analysis");
      console.error(error);
    }
  };

  // Timeline
  const openTimeline = () => {
    if (!activeConversation) return;
    setShowTimeline(true);
  };

  return (
    <div className="h-screen w-screen flex overflow-hidden bg-background text-foreground" style={{ fontSize: `${settings.fontSize}px` }}>
      {/* Sidebar */}
      <aside
        className={`${
          sidebarCollapsed ? "w-0" : "w-64"
        } transition-all duration-300 border-r border-border bg-sidebar flex flex-col overflow-hidden ${
          isMobile ? (sidebarCollapsed ? "hidden" : "fixed inset-0 z-50 w-full") : "md:flex"
        }`}
      >
        {isMobile && !sidebarCollapsed && (
          <div className="absolute top-4 right-4 z-50">
            <Button variant="ghost" size="icon" onClick={() => setSidebarCollapsed(true)}>
              <X className="h-6 w-6" />
            </Button>
          </div>
        )}
        <div className="p-3 border-b border-border space-y-2">
          <Button
            onClick={createNewConversation}
            className="w-full justify-start bg-transparent hover:bg-accent text-foreground border border-border"
            size="sm"
          >
            <Plus className="h-4 w-4 mr-2" />
            New chat
          </Button>
          
          {showSearch && (
            <Input
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-input text-sm"
            />
          )}
        </div>

        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {filteredConversations.map((conv) => (
              <div
                key={conv.id}
                className={`group relative px-3 py-2 rounded-lg cursor-pointer transition-colors ${
                  activeConversationId === conv.id
                    ? "bg-accent"
                    : "hover:bg-accent/50"
                }`}
                onClick={() => setActiveConversationId(conv.id)}
              >
                <div className="flex items-center gap-2">
                  {conv.isPinned && <Pin className="h-3 w-3 text-primary flex-shrink-0" />}
                  <MessageSquare className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
                  <span className="text-sm truncate flex-1">{conv.title}</span>
                  <div className="opacity-0 group-hover:opacity-100 flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={(e) => {
                        e.stopPropagation();
                        togglePin(conv.id);
                      }}
                    >
                      <Pin className="h-3 w-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteConversation(conv.id);
                      }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                {conv.tags && conv.tags.length > 0 && (
                  <div className="flex gap-1 mt-1 flex-wrap">
                    {conv.tags.map(tag => (
                      <span key={tag} className="text-xs bg-primary/20 px-1 rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="p-3 border-t border-border space-y-1">
          <Button
            onClick={() => setShowSearch(!showSearch)}
            variant="ghost"
            className="w-full justify-start text-sm"
            size="sm"
          >
            <Search className="h-4 w-4 mr-2" />
            Search
          </Button>
          <Button
            onClick={() => setShowFavorites(!showFavorites)}
            variant="ghost"
            className="w-full justify-start text-sm"
            size="sm"
          >
            <Star className="h-4 w-4 mr-2" />
            Favorites
          </Button>
          <Button
            onClick={() => setShowStats(!showStats)}
            variant="ghost"
            className="w-full justify-start text-sm"
            size="sm"
          >
            <BarChart3 className="h-4 w-4 mr-2" />
            Statistics
          </Button>
          <Button
            onClick={() => setShowSettings(!showSettings)}
            variant="ghost"
            className="w-full justify-start text-sm"
            size="sm"
          >
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
          <Button
            onClick={logout}
            variant="ghost"
            className="w-full justify-start text-sm text-destructive"
            size="sm"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="flex-shrink-0 border-b border-border bg-card/50 backdrop-blur">
          <div className="flex items-center justify-between px-3 md:px-6 py-3">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                className="h-8 w-8"
              >
                {isMobile ? (
                  <Menu className="h-5 w-5" />
                ) : (
                  <ChevronRight
                    className={`h-5 w-5 transition-transform ${
                      sidebarCollapsed ? "" : "rotate-180"
                    }`}
                  />
                )}
              </Button>
              <div className="flex items-center gap-2">
                <img
                  src="/images/wormgpt-logo.png"
                  alt="WormGPT"
                  className="h-6 w-6 rounded-full"
                />
                <span className="font-semibold text-sm">WormGPT</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <div
                  className={`h-2 w-2 rounded-full ${
                    isConnected ? "bg-green-500" : "bg-red-500"
                  }`}
                />
                <span>{isConnected ? "Connected" : "Disconnected"}</span>
              </div>
              
              <Dialog open={showExportDialog} onOpenChange={setShowExportDialog}>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Download className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Export Conversation</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-3">
                    <Button onClick={() => { exportConversation("json"); setShowExportDialog(false); }} className="w-full">
                      <FileJson className="h-4 w-4 mr-2" />
                      Export as JSON
                    </Button>
                    <Button onClick={() => { exportConversation("txt"); setShowExportDialog(false); }} className="w-full">
                      <FileText className="h-4 w-4 mr-2" />
                      Export as TXT
                    </Button>
                    <Button onClick={() => { exportConversation("md"); setShowExportDialog(false); }} className="w-full">
                      <FileCode className="h-4 w-4 mr-2" />
                      Export as Markdown
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={importConversation}
                className="hidden"
              />
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => fileInputRef.current?.click()}
                title="Import Conversation"
              >
                <Upload className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={printConversation}
                title="Print"
              >
                <Printer className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={copyEntireConversation}
                title="Copy All"
              >
                <FileCode className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => setShowContextVisualizer(!showContextVisualizer)}
                title="Context Window"
              >
                <TrendingUp className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={openTimeline}
                title="Timeline Replay"
              >
                <Clock className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={startConsensusMode}
                title="Multi-Model Consensus"
                disabled={selectedModelsForConsensus.length < 2}
              >
                <GitBranch className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </header>

        {/* Chat Area or Settings */}
        {showSettings ? (
          <ScrollArea className="flex-1">
            <div className="max-w-2xl mx-auto p-6 space-y-6">
              <div>
                <h2 className="text-2xl font-semibold mb-2">Settings</h2>
                <p className="text-sm text-muted-foreground">
                  Configure your WormGPT experience
                </p>
              </div>

              {/* Ollama Connection */}
              <div className="space-y-4 border border-border rounded-lg p-4">
                <h3 className="font-semibold">Ollama Connection</h3>
                
                <div>
                  <Label>API URL</Label>
                  <Input
                    value={settings.ollamaUrl}
                    onChange={(e) => {
                      const newSettings = { ...settings, ollamaUrl: e.target.value };
                      setSettings(newSettings);
                      StorageService.saveSettings(newSettings);
                    }}
                    placeholder="http://localhost:11434"
                    className="bg-input mt-2"
                  />
                </div>

                <div>
                  <Label>Model</Label>
                  <Select
                    value={settings.selectedModel}
                    onValueChange={(value) => {
                      const newSettings = { ...settings, selectedModel: value };
                      setSettings(newSettings);
                      StorageService.saveSettings(newSettings);
                    }}
                  >
                    <SelectTrigger className="bg-input mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {availableModels.map((model) => (
                        <SelectItem key={model.name} value={model.name}>
                          {model.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-2">
                    Recommended: <span className="text-primary font-semibold">{RECOMMENDED_MODEL}</span>
                  </p>
                </div>

                <Button onClick={testConnection} className="bg-primary text-primary-foreground">
                  Test Connection
                </Button>
                
                {/* Consensus Mode Models */}
                <div className="mt-4">
                  <Label>Consensus Mode Models</Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Select 2+ models for comparison
                  </p>
                  <div className="space-y-2 max-h-40 overflow-auto">
                    {availableModels.map((model) => (
                      <div key={model.name} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          id={`consensus-${model.name}`}
                          checked={selectedModelsForConsensus.includes(model.name)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedModelsForConsensus([...selectedModelsForConsensus, model.name]);
                            } else {
                              setSelectedModelsForConsensus(selectedModelsForConsensus.filter(m => m !== model.name));
                            }
                          }}
                          className="rounded"
                        />
                        <label htmlFor={`consensus-${model.name}`} className="text-sm cursor-pointer">
                          {model.name}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* AI Behavior */}
              <div className="space-y-4 border border-border rounded-lg p-4">
                <h3 className="font-semibold">AI Behavior</h3>
                
                <div>
                  <Label>Temperature: {settings.temperature}</Label>
                  <Slider
                    value={[settings.temperature]}
                    onValueChange={([value]) => {
                      const newSettings = { ...settings, temperature: value };
                      setSettings(newSettings);
                      StorageService.saveSettings(newSettings);
                    }}
                    min={0}
                    max={2}
                    step={0.1}
                    className="mt-2"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Higher = more creative, Lower = more focused
                  </p>
                </div>

                <div>
                  <Label>Stream Speed: {settings.streamSpeed}ms</Label>
                  <Slider
                    value={[settings.streamSpeed]}
                    onValueChange={([value]) => {
                      const newSettings = { ...settings, streamSpeed: value };
                      setSettings(newSettings);
                      StorageService.saveSettings(newSettings);
                    }}
                    min={0}
                    max={200}
                    step={10}
                    className="mt-2"
                  />
                </div>
              </div>

              {/* Web Search & OSINT */}
              <div className="space-y-4 border border-red-900/30 rounded-lg p-4 bg-red-950/10">
                <div className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-red-500" />
                  <h3 className="font-semibold text-red-400">Web Search & OSINT</h3>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-sm font-medium">Enable Web Search</Label>
                    <p className="text-xs text-muted-foreground mt-1">
                      Search the internet and perform OSINT
                    </p>
                  </div>
                  <Switch
                    checked={webSearchEnabled}
                    onCheckedChange={(checked) => {
                      setWebSearchEnabled(checked);
                      webSearchService.setEnabled(checked);
                      if (checked) {
                        toast.success("Web search enabled - AI can now search the internet");
                      } else {
                        toast.info("Web search disabled");
                      }
                    }}
                  />
                </div>

                {webSearchEnabled && (
                  <div className="bg-red-950/20 border border-red-900/50 rounded p-3 space-y-2">
                    <div className="flex items-start gap-2">
                      <Shield className="h-4 w-4 text-red-400 mt-0.5" />
                      <div className="text-xs text-red-300">
                        <p className="font-semibold mb-1">Web Search Active</p>
                        <p className="text-red-400/80">
                          AI can search websites, gather data, and download files. Use responsibly.
                        </p>
                      </div>
                    </div>
                    <Button
                      onClick={() => setShowOSINTDashboard(true)}
                      variant="outline"
                      size="sm"
                      className="w-full border-red-800 text-red-400 hover:bg-red-950/30"
                    >
                      <Globe className="h-4 w-4 mr-2" />
                      View OSINT Activity
                    </Button>
                  </div>
                )}
              </div>

              {/* Appearance */}
              <div className="space-y-4 border border-border rounded-lg p-4">
                <h3 className="font-semibold">Appearance</h3>
                
                <div className="flex items-center justify-between">
                  <Label>Theme</Label>
                  <div className="flex gap-2">
                    <Button
                      variant={theme === "light" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setTheme?.("light")}
                    >
                      <Sun className="h-4 w-4 mr-2" />
                      Light
                    </Button>
                    <Button
                      variant={theme === "dark" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setTheme?.("dark")}
                    >
                      <Moon className="h-4 w-4 mr-2" />
                      Dark
                    </Button>
                  </div>
                </div>

                <div>
                  <Label>Font Size: {settings.fontSize}px</Label>
                  <Slider
                    value={[settings.fontSize]}
                    onValueChange={([value]) => {
                      const newSettings = { ...settings, fontSize: value };
                      setSettings(newSettings);
                      StorageService.saveSettings(newSettings);
                    }}
                    min={12}
                    max={20}
                    step={1}
                    className="mt-2"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>Auto-scroll</Label>
                  <Switch
                    checked={settings.autoScroll}
                    onCheckedChange={(checked) => {
                      const newSettings = { ...settings, autoScroll: checked };
                      setSettings(newSettings);
                      StorageService.saveSettings(newSettings);
                    }}
                  />
                </div>
              </div>

              {/* Features */}
              <div className="space-y-4 border border-border rounded-lg p-4">
                <h3 className="font-semibold">Features</h3>
                
                <div className="flex items-center justify-between">
                  <Label>Sound Effects</Label>
                  <Switch
                    checked={settings.soundEnabled}
                    onCheckedChange={(checked) => {
                      const newSettings = { ...settings, soundEnabled: checked };
                      setSettings(newSettings);
                      StorageService.saveSettings(newSettings);
                    }}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label>Desktop Notifications</Label>
                  <Switch
                    checked={settings.notificationsEnabled}
                    onCheckedChange={(checked) => {
                      const newSettings = { ...settings, notificationsEnabled: checked };
                      setSettings(newSettings);
                      StorageService.saveSettings(newSettings);
                      if (checked) {
                        Notification.requestPermission();
                      }
                    }}
                  />
                </div>
              </div>

              {/* Data Management */}
              <div className="space-y-4 border border-border rounded-lg p-4">
                <h3 className="font-semibold">Data Management</h3>
                
                <Button
                  variant="destructive"
                  onClick={() => {
                    if (confirm("Clear all conversations? This cannot be undone.")) {
                      StorageService.clearAllConversations();
                      setConversations([]);
                      createNewConversation();
                      toast.success("All data cleared");
                    }
                  }}
                  className="w-full"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Clear All Data
                </Button>
              </div>
            </div>
          </ScrollArea>
        ) : showStats ? (
          <div className="flex-1 overflow-auto p-6">
            <div className="max-w-2xl mx-auto space-y-6">
              <h2 className="text-2xl font-semibold">Statistics</h2>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="border border-border rounded-lg p-4 text-center">
                  <div className="text-3xl font-bold text-primary">{stats.totalConversations}</div>
                  <div className="text-sm text-muted-foreground mt-1">Conversations</div>
                </div>
                <div className="border border-border rounded-lg p-4 text-center">
                  <div className="text-3xl font-bold text-primary">{stats.totalMessages}</div>
                  <div className="text-sm text-muted-foreground mt-1">Messages</div>
                </div>
                <div className="border border-border rounded-lg p-4 text-center">
                  <div className="text-3xl font-bold text-primary">{stats.totalWords}</div>
                  <div className="text-sm text-muted-foreground mt-1">Words</div>
                </div>
              </div>

              <Button onClick={() => setShowStats(false)} className="w-full">
                Back to Chat
              </Button>
            </div>
          </div>
        ) : showFavorites ? (
          <div className="flex-1 overflow-auto p-6">
            <div className="max-w-2xl mx-auto space-y-6">
              <h2 className="text-2xl font-semibold">Favorite Prompts</h2>
              
              <div className="space-y-2">
                {favorites.map((fav, index) => (
                  <div key={index} className="border border-border rounded-lg p-3 flex items-center justify-between">
                    <span className="text-sm flex-1">{fav}</span>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => {
                          setInputValue(fav);
                          setShowFavorites(false);
                        }}
                      >
                        Use
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          StorageService.removeFavorite(fav);
                          setFavorites(favorites.filter((_, i) => i !== index));
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <Button onClick={() => setShowFavorites(false)} className="w-full">
                Back to Chat
              </Button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto overflow-x-hidden" ref={scrollAreaRef}>
              {activeConversation?.messages.length === 0 ? (
                <div className="h-full flex items-center justify-center p-6">
                  <div className="text-center space-y-6 max-w-2xl">
                    <div className="flex justify-center">
                      <img
                        src="/images/wormgpt-logo.png"
                        alt="WormGPT"
                        className="h-16 w-16 rounded-full"
                      />
                    </div>
                    <div>
                      <h1 className="text-3xl font-semibold mb-3">WormGPT</h1>
                      <p className="text-muted-foreground text-sm">
                        Unfiltered AI assistant. No restrictions.
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="max-w-3xl mx-auto px-3 md:px-4 py-4 md:py-6 w-full">
                  {activeConversation?.messages.map((message) => (
                    <div
                      key={message.id}
                      className={`mb-6 flex gap-4 ${
                        message.role === "user" ? "flex-row-reverse" : ""
                      }`}
                    >
                      <div className="flex-shrink-0">
                        {message.role === "assistant" ? (
                          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                            <img
                              src="/images/wormgpt-logo.png"
                              alt="AI"
                              className="h-5 w-5 rounded-full"
                            />
                          </div>
                        ) : (
                          <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center text-xs font-semibold">
                            U
                          </div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0 space-y-2">
                        {editingMessageId === message.id ? (
                          <div className="space-y-2">
                            <Textarea
                              value={editingText}
                              onChange={(e) => setEditingText(e.target.value)}
                              className="min-h-[100px]"
                            />
                            <div className="flex gap-2">
                              <Button size="sm" onClick={saveEditedMessage}>
                                <Check className="h-4 w-4 mr-2" />
                                Save
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => {
                                  setEditingMessageId(null);
                                  setEditingText("");
                                }}
                              >
                                <X className="h-4 w-4 mr-2" />
                                Cancel
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <>
                            <div className="prose prose-invert prose-sm max-w-none break-words overflow-wrap-anywhere">
                              <Streamdown>{message.content}</Streamdown>
                            </div>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => copyToClipboard(message.content, message.id)}
                                title="Copy"
                              >
                                {copiedId === message.id ? (
                                  <Check className="h-3 w-3" />
                                ) : (
                                  <Copy className="h-3 w-3" />
                                )}
                              </Button>
                              {message.role === "assistant" && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7"
                                  onClick={() => speakMessage(message.content)}
                                  title="Text-to-Speech"
                                >
                                  <Volume2 className={`h-3 w-3 ${isSpeaking ? 'text-primary' : ''}`} />
                                </Button>
                              )}
                              {message.role === "user" && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7"
                                  onClick={() => editMessage(message.id)}
                                  title="Edit"
                                >
                                  <Edit2 className="h-3 w-3" />
                                </Button>
                              )}
                              {message.role === "assistant" && (
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7"
                                  onClick={() => regenerateMessage(message.id)}
                                  title="Regenerate"
                                >
                                  <RotateCcw className="h-3 w-3" />
                                </Button>
                              )}
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                  {isStreaming && (
                    <div className="flex justify-center">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={stopGeneration}
                      >
                        <StopCircle className="h-4 w-4 mr-2" />
                        Stop Generation
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Input Area */}
            <div className="flex-shrink-0 border-t border-border bg-card/50 backdrop-blur p-2 md:p-4 sticky bottom-0 z-10">
              <div className="max-w-3xl mx-auto">
                <div className="relative">
                  <Textarea
                    ref={textareaRef}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Message WormGPT..."
                    className={`min-h-[56px] max-h-[200px] resize-none ${isMobile ? 'pr-12 pb-12' : 'pr-24'} bg-input rounded-2xl`}
                    rows={1}
                    disabled={isStreaming}
                  />
                  <div className={`absolute right-2 bottom-2 flex ${isMobile ? 'w-full justify-between px-2' : 'gap-1'}`}>
                    {isMobile && (
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => setShowTemplates(!showTemplates)}
                        >
                          <FileText className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => imageInputRef.current?.click()}
                        >
                          <ImageIcon className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className={`h-8 w-8 ${isRecording ? 'text-red-500 animate-pulse' : ''}`}
                          onClick={isRecording ? stopVoiceInput : startVoiceInput}
                        >
                          <Mic className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                    <div className="flex gap-1 ml-auto">
                      {!isMobile && (
                        <>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => setShowTemplates(!showTemplates)}
                            title="Templates"
                          >
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => imageInputRef.current?.click()}
                            title="Upload Image"
                          >
                            <ImageIcon className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className={`h-8 w-8 ${isRecording ? 'text-red-500 animate-pulse' : ''}`}
                            onClick={isRecording ? stopVoiceInput : startVoiceInput}
                            title="Voice Input"
                          >
                            <Mic className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => {
                          if (inputValue.trim()) {
                            StorageService.saveFavorite(inputValue);
                            setFavorites([...favorites, inputValue]);
                            toast.success("Added to favorites");
                          }
                        }}
                        title="Add to Favorites"
                      >
                        <Star className="h-4 w-4" />
                      </Button>
                      <Button
                        onClick={() => sendMessage()}
                        disabled={!inputValue.trim() || isStreaming}
                        size="icon"
                        className="h-8 w-8 rounded-lg bg-primary text-primary-foreground disabled:opacity-30"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <input
                    ref={imageInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>
                
                {/* Templates Panel */}
                {showTemplates && (
                  <div className="mt-2 p-3 border border-border rounded-lg bg-card">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-semibold">Templates</h3>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => setShowTemplates(false)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-2 gap-2 max-h-60 overflow-auto">
                      {templates.map((template) => (
                        <Button
                          key={template.id}
                          variant="outline"
                          size="sm"
                          className="justify-start text-left h-auto py-2"
                          onClick={() => useTemplate(template)}
                        >
                          <div>
                            <div className="font-semibold text-xs">{template.title}</div>
                            <div className="text-xs text-muted-foreground truncate">
                              {template.category}
                            </div>
                          </div>
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Uploaded Images Preview */}
                {uploadedImages.length > 0 && (
                  <div className="mt-2 flex gap-2 flex-wrap">
                    {uploadedImages.map((img, index) => (
                      <div key={index} className="relative">
                        <img
                          src={img}
                          alt="Upload"
                          className="h-16 w-16 object-cover rounded border border-border"
                        />
                        <Button
                          variant="destructive"
                          size="icon"
                          className="absolute -top-2 -right-2 h-5 w-5"
                          onClick={() => setUploadedImages(uploadedImages.filter((_, i) => i !== index))}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </main>

      {/* Context Visualizer Sidebar */}
      {showContextVisualizer && contextAnalysis && (
        <div className="fixed right-4 top-20 w-80 z-40">
          <ContextVisualizer analysis={contextAnalysis} />
        </div>
      )}

      {/* Consensus View Overlay */}
      {showConsensusMode && consensusResponses.length > 0 && consensusAnalysis && (
        <ConsensusView
          responses={consensusResponses}
          analysis={consensusAnalysis}
          onClose={() => {
            setShowConsensusMode(false);
            setConsensusResponses([]);
            setConsensusAnalysis(null);
          }}
        />
      )}

      {/* Timeline Overlay */}
      {showTimeline && activeConversation && (
        <ConversationTimeline
          conversation={activeConversation}
          onClose={() => setShowTimeline(false)}
        />
      )}

      {/* OSINT Dashboard */}
      <OSINTDashboard
        isOpen={showOSINTDashboard}
        onClose={() => setShowOSINTDashboard(false)}
      />
    </div>
  );
}

import { useEffect, useRef } from "react";

export function Watermark() {
  const watermarkRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Protection: Monitor for removal attempts
    const checkInterval = setInterval(() => {
      if (!watermarkRef.current || !document.body.contains(watermarkRef.current)) {
        window.location.reload();
      }
    }, 2000);

    return () => clearInterval(checkInterval);
  }, []);

  return (
    <div
      ref={watermarkRef}
      style={{
        position: "fixed",
        bottom: 0,
        left: 0,
        right: 0,
        backgroundColor: "#0a0a0a",
        color: "#888",
        fontSize: "10px",
        padding: "6px 12px",
        textAlign: "center",
        zIndex: 9999,
        borderTop: "1px solid #222",
      }}
    >
      WormGPT is made by <strong style={{ color: "#dc2626" }}>MRZXN</strong> | visit{" "}
      <a
        href="https://mrzxnportal.netlify.app"
        target="_blank"
        rel="noopener noreferrer"
        style={{ color: "#dc2626", textDecoration: "none" }}
      >
        mrzxnportal.netlify.app
      </a>{" "}
      to request custom websites
    </div>
  );
}

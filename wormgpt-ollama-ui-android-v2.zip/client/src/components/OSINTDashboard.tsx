import { useEffect, useState } from "react";
import { X, Search, Download, Globe, AlertCircle, CheckCircle, Loader2 } from "lucide-react";
import { webSearchService, OSINTActivity } from "@/lib/web-search";
import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";

interface OSINTDashboardProps {
  isOpen: boolean;
  onClose: () => void;
}

export function OSINTDashboard({ isOpen, onClose }: OSINTDashboardProps) {
  const [activities, setActivities] = useState<OSINTActivity[]>([]);

  useEffect(() => {
    if (isOpen) {
      setActivities(webSearchService.getActivities());

      const callback = (activity: OSINTActivity) => {
        setActivities((prev) => [...prev, activity]);
      };

      webSearchService.onActivity(callback);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const getStatusIcon = (status: OSINTActivity["status"]) => {
    switch (status) {
      case "searching":
        return <Loader2 className="w-4 h-4 animate-spin text-yellow-500" />;
      case "found":
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "failed":
        return <AlertCircle className="w-4 h-4 text-red-500" />;
    }
  };

  const getActionIcon = (action: string) => {
    if (action.includes("Search")) return <Search className="w-4 h-4" />;
    if (action.includes("Download")) return <Download className="w-4 h-4" />;
    return <Globe className="w-4 h-4" />;
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[10000] flex items-center justify-center p-4">
      <div className="bg-[#1a1a1a] border border-[#333] rounded-lg w-full max-w-3xl max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#333]">
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-red-500" />
            <h2 className="text-lg font-semibold">OSINT Activity Monitor</h2>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                webSearchService.clearActivities();
                setActivities([]);
              }}
            >
              Clear
            </Button>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Activity List */}
        <ScrollArea className="flex-1 p-4">
          {activities.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-500 py-12">
              <Globe className="w-12 h-12 mb-4 opacity-50" />
              <p>No activity yet</p>
              <p className="text-sm mt-1">Enable web search and start searching</p>
            </div>
          ) : (
            <div className="space-y-3">
              {activities.map((activity) => (
                <div
                  key={activity.id}
                  className="bg-[#0f0f0f] border border-[#333] rounded-lg p-3"
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1">{getActionIcon(activity.action)}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">{activity.action}</span>
                        {getStatusIcon(activity.status)}
                      </div>
                      <p className="text-sm text-gray-400 truncate">{activity.target}</p>
                      {activity.results && activity.results.length > 0 && (
                        <div className="mt-2 space-y-1">
                          {activity.results.map((result, idx) => (
                            <p key={idx} className="text-xs text-green-400">
                              {result}
                            </p>
                          ))}
                        </div>
                      )}
                      <p className="text-xs text-gray-600 mt-2">
                        {new Date(activity.timestamp).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>

        {/* Footer */}
        <div className="p-4 border-t border-[#333] bg-[#0f0f0f]">
          <div className="flex items-center justify-between text-xs text-gray-500">
            <span>{activities.length} activities logged</span>
            <span>
              {activities.filter((a) => a.status === "searching").length} in progress
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

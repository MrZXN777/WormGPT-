# WormGPT Ollama UI - Android (Termux) Installation

This version is specifically optimized for Android using **Termux**.

## One-Command Installation

To install everything (Ollama, Node.js, pnpm, and the LLM model) automatically, open Termux and run:

```bash
curl -sL https://raw.githubusercontent.com/your-username/wormgpt-ollama-ui/main/install-termux.sh | bash
```

*(Note: Replace the URL with your actual hosted script URL or use the local method below)*

## Local Installation (Using the provided files)

If you have extracted the files into a folder in Termux:

1.  **Navigate to the folder:**
    ```bash
    cd wormgpt-ollama-ui
    ```

2.  **Make the installer executable:**
    ```bash
    chmod +x install-termux.sh
    ```

3.  **Run the installer:**
    ```bash
    ./install-termux.sh
    ```

## How to Start

After installation, you can start the application anytime by running:

```bash
./start.sh
```

- **Web UI:** `http://localhost:3000`
- **Password:** `Realnojokepplwazy1234`

## Requirements

- **Android Device:** Recommended 8GB+ RAM for smooth LLM performance.
- **Storage:** At least 5GB free space for the LLM model.
- **Termux:** Installed from [F-Droid](https://f-droid.org/en/packages/com.termux/) (Play Store version is outdated).

## Troubleshooting

- **Ollama not starting:** Run `ollama serve` manually in a separate Termux session to see error logs.
- **Slow performance:** This is normal on mobile devices. The `llama3-lexi-uncensored` model is optimized but still requires significant CPU/GPU power.
- **Permission Denied:** Ensure you ran `termux-setup-storage` if you are accessing files from internal storage.

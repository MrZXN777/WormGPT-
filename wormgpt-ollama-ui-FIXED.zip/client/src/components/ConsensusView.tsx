import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Lightbulb, TrendingUp, Copy, Check } from "lucide-react";
import { Streamdown } from "streamdown";
import type { ModelResponse, ConsensusAnalysis } from "@/lib/consensus";
import { useState } from "react";
import { toast } from "sonner";

interface ConsensusViewProps {
  responses: ModelResponse[];
  analysis: ConsensusAnalysis;
  onClose: () => void;
}

export function ConsensusView({ responses, analysis, onClose }: ConsensusViewProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = async (text: string, id: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedId(id);
    toast.success("Copied to clipboard");
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-0 bg-background/95 backdrop-blur z-50 flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold">Multi-Model Consensus</h2>
            <p className="text-sm text-muted-foreground">
              Comparing {responses.length} models • Confidence: {(analysis.confidence * 100).toFixed(0)}%
            </p>
          </div>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        <div className="max-w-6xl mx-auto p-6 space-y-6">
          {/* Analysis Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Agreements */}
            <div className="p-4 border border-border rounded-lg bg-green-500/5">
              <div className="flex items-center gap-2 mb-3">
                <CheckCircle className="h-5 w-5 text-green-500" />
                <h3 className="font-semibold">Agreements</h3>
                <Badge variant="secondary">{analysis.agreements.length}</Badge>
              </div>
              <ScrollArea className="h-40">
                <div className="space-y-2">
                  {analysis.agreements.length > 0 ? (
                    analysis.agreements.map((agreement, i) => (
                      <div key={i} className="text-xs p-2 bg-background/50 rounded border border-border">
                        {agreement}
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-muted-foreground">No common agreements found</p>
                  )}
                </div>
              </ScrollArea>
            </div>

            {/* Disagreements */}
            <div className="p-4 border border-border rounded-lg bg-red-500/5">
              <div className="flex items-center gap-2 mb-3">
                <XCircle className="h-5 w-5 text-red-500" />
                <h3 className="font-semibold">Disagreements</h3>
                <Badge variant="secondary">{analysis.disagreements.length}</Badge>
              </div>
              <ScrollArea className="h-40">
                <div className="space-y-2">
                  {analysis.disagreements.length > 0 ? (
                    analysis.disagreements.map((disagreement, i) => (
                      <div key={i} className="text-xs p-2 bg-background/50 rounded border border-border">
                        {disagreement}
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-muted-foreground">No contradictions detected</p>
                  )}
                </div>
              </ScrollArea>
            </div>

            {/* Unique Insights */}
            <div className="p-4 border border-border rounded-lg bg-blue-500/5">
              <div className="flex items-center gap-2 mb-3">
                <Lightbulb className="h-5 w-5 text-blue-500" />
                <h3 className="font-semibold">Unique Insights</h3>
                <Badge variant="secondary">{analysis.uniqueInsights.size}</Badge>
              </div>
              <ScrollArea className="h-40">
                <div className="space-y-2">
                  {Array.from(analysis.uniqueInsights.entries()).map(([model, insights]) => (
                    <div key={model} className="text-xs">
                      <div className="font-semibold text-blue-500 mb-1">{model}</div>
                      {insights.slice(0, 2).map((insight, i) => (
                        <div key={i} className="p-2 bg-background/50 rounded border border-border mb-1">
                          {insight}
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </div>

          {/* Best Response Highlight */}
          {analysis.bestResponse && (
            <div className="p-4 border-2 border-primary rounded-lg bg-primary/5">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                <h3 className="font-semibold">Recommended Response</h3>
                <Badge variant="default">{analysis.bestResponse}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">
                This response was selected based on comprehensiveness, speed, and quality.
              </p>
            </div>
          )}

          {/* Individual Model Responses */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Individual Responses</h3>
            <Tabs defaultValue={responses[0]?.model || ""} className="w-full">
              <TabsList className="grid w-full" style={{ gridTemplateColumns: `repeat(${responses.length}, 1fr)` }}>
                {responses.map((response) => (
                  <TabsTrigger key={response.model} value={response.model} className="text-xs">
                    {response.model}
                    {analysis.bestResponse === response.model && (
                      <TrendingUp className="h-3 w-3 ml-1 text-primary" />
                    )}
                  </TabsTrigger>
                ))}
              </TabsList>
              {responses.map((response) => (
                <TabsContent key={response.model} value={response.model} className="mt-4">
                  <div className="border border-border rounded-lg p-4 bg-card">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>Model: <span className="font-semibold text-foreground">{response.model}</span></span>
                        {response.tokensPerSecond && (
                          <span>{response.tokensPerSecond.toFixed(1)} tokens/s</span>
                        )}
                        {response.totalTime && (
                          <span>{(response.totalTime / 1000).toFixed(2)}s</span>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => copyToClipboard(response.content, response.model)}
                      >
                        {copiedId === response.model ? (
                          <Check className="h-4 w-4" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                    <ScrollArea className="h-96">
                      <div className="prose prose-invert prose-sm max-w-none">
                        <Streamdown>{response.content}</Streamdown>
                      </div>
                    </ScrollArea>
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}

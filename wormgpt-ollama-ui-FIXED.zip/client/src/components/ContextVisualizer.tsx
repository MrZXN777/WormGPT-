import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, CheckCircle, Pin, TrendingUp, Zap } from "lucide-react";
import type { ContextAnalysis } from "@/lib/context-analyzer";

interface ContextVisualizerProps {
  analysis: ContextAnalysis;
  onPinMessage?: (messageId: string) => void;
  pinnedMessages?: string[];
}

export function ContextVisualizer({ analysis }: ContextVisualizerProps) {
  const getHealthColor = (score: number) => {
    if (score >= 80) return "text-green-500";
    if (score >= 50) return "text-yellow-500";
    return "text-red-500";
  };

  const getHealthIcon = (score: number) => {
    if (score >= 80) return <CheckCircle className="h-4 w-4" />;
    if (score >= 50) return <AlertCircle className="h-4 w-4" />;
    return <AlertCircle className="h-4 w-4" />;
  };

  const getUsageColor = (percentage: number) => {
    if (percentage >= 90) return "bg-red-500";
    if (percentage >= 75) return "bg-yellow-500";
    if (percentage >= 50) return "bg-blue-500";
    return "bg-green-500";
  };

  return (
    <div className="space-y-3 p-4 border border-border rounded-lg bg-card/50">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Zap className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-semibold">Context Window</h3>
        </div>
        <div className={`flex items-center gap-1 ${getHealthColor(analysis.healthScore)}`}>
          {getHealthIcon(analysis.healthScore)}
          <span className="text-xs font-semibold">{analysis.healthScore}%</span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="space-y-1">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Usage</span>
          <span>{analysis.totalTokens.toLocaleString()} / {analysis.maxTokens.toLocaleString()} tokens</span>
        </div>
        <div className="relative">
          <Progress 
            value={Math.min(analysis.usagePercentage, 100)} 
            className="h-2"
          />
          <div 
            className={`absolute top-0 left-0 h-2 rounded-full transition-all ${getUsageColor(analysis.usagePercentage)}`}
            style={{ width: `${Math.min(analysis.usagePercentage, 100)}%` }}
          />
        </div>
        <div className="text-xs text-center font-semibold">
          {analysis.usagePercentage.toFixed(1)}% used
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="p-2 bg-background/50 rounded border border-border">
          <div className="text-muted-foreground">In Context</div>
          <div className="text-lg font-bold text-green-500">{analysis.messagesInContext}</div>
        </div>
        <div className="p-2 bg-background/50 rounded border border-border">
          <div className="text-muted-foreground">Out of Context</div>
          <div className="text-lg font-bold text-red-500">{analysis.messagesOutOfContext}</div>
        </div>
      </div>

      {/* Warnings */}
      {analysis.warnings.length > 0 && (
        <div className="space-y-1">
          {analysis.warnings.map((warning, index) => (
            <div 
              key={index}
              className="flex items-start gap-2 text-xs p-2 bg-yellow-500/10 border border-yellow-500/20 rounded"
            >
              <AlertCircle className="h-3 w-3 text-yellow-500 flex-shrink-0 mt-0.5" />
              <span className="text-yellow-500">{warning}</span>
            </div>
          ))}
        </div>
      )}

      {/* Quick Actions */}
      <div className="flex gap-2 pt-2 border-t border-border">
        <Button 
          variant="outline" 
          size="sm" 
          className="flex-1 text-xs h-7"
          disabled
        >
          <Pin className="h-3 w-3 mr-1" />
          Pin Important
        </Button>
        <Button 
          variant="outline" 
          size="sm" 
          className="flex-1 text-xs h-7"
          disabled
        >
          <TrendingUp className="h-3 w-3 mr-1" />
          Summarize Old
        </Button>
      </div>
    </div>
  );
}

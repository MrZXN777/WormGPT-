import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Play, Pause, SkipBack, SkipForward, Download, X, Zap } from "lucide-react";
import { useState, useEffect } from "react";
import { Streamdown } from "streamdown";
import { TimelineService, type TimelineEvent } from "@/lib/timeline";
import type { Conversation, Message } from "@/lib/storage";
import { toast } from "sonner";

interface ConversationTimelineProps {
  conversation: Conversation;
  onClose: () => void;
  onBranchFrom?: (messageId: string) => void;
}

export function ConversationTimeline({ conversation, onClose, onBranchFrom }: ConversationTimelineProps) {
  const [events] = useState<TimelineEvent[]>(() => TimelineService.buildTimeline(conversation));
  const [currentIndex, setCurrentIndex] = useState(events.length - 1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [displayedMessages, setDisplayedMessages] = useState<Message[]>([]);
  
  const stats = TimelineService.getTimelineStats(events);
  const heatmap = TimelineService.calculateHeatmap(conversation);
  const branchPoints = TimelineService.findBranchPoints(conversation);

  useEffect(() => {
    const messages = TimelineService.getMessagesUpToIndex(events, currentIndex);
    setDisplayedMessages(messages);
  }, [currentIndex, events]);

  const handlePlay = async () => {
    if (isPlaying) {
      setIsPlaying(false);
      return;
    }

    setIsPlaying(true);
    
    try {
      await TimelineService.playTimeline(
        events,
        playbackSpeed,
        (event, index) => {
          setCurrentIndex(index);
        },
        currentIndex + 1
      );
    } catch (error) {
      console.error("Playback error:", error);
    } finally {
      setIsPlaying(false);
    }
  };

  const handleSliderChange = (value: number[]) => {
    setCurrentIndex(value[0]);
    setIsPlaying(false);
  };

  const handleExport = () => {
    const exported = TimelineService.exportTimeline(conversation);
    navigator.clipboard.writeText(exported);
    toast.success("Timeline exported to clipboard");
  };

  const getHeatmapIntensity = (messageId: string): number => {
    let maxIntensity = 0;
    heatmap.forEach((value, key) => {
      if (key.includes(messageId)) {
        maxIntensity = Math.max(maxIntensity, value);
      }
    });
    return maxIntensity;
  };

  return (
    <div className="fixed inset-0 bg-background/95 backdrop-blur z-50 flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold">Conversation Timeline</h2>
            <p className="text-sm text-muted-foreground">
              {stats.messageCount} messages • {(stats.totalDuration / 1000 / 60).toFixed(1)} min duration
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button variant="outline" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Timeline Visualization */}
      <div className="border-b border-border p-4 bg-card/30">
        <div className="max-w-6xl mx-auto space-y-4">
          {/* Timeline Bar with Heatmap */}
          <div className="relative h-12">
            <div className="absolute inset-0 flex items-center">
              {events.map((event, index) => {
                const position = (index / (events.length - 1)) * 100;
                const intensity = event.messageId ? getHeatmapIntensity(event.messageId) : 0;
                const isBranchPoint = event.messageId ? branchPoints.includes(event.messageId) : false;
                
                return (
                  <div
                    key={event.id}
                    className="absolute w-2 h-2 rounded-full cursor-pointer transition-all hover:scale-150"
                    style={{
                      left: `${position}%`,
                      backgroundColor: intensity > 0 
                        ? `rgba(220, 38, 38, ${Math.min(intensity / 3, 1)})`
                        : event.role === "user" 
                        ? "#3b82f6" 
                        : "#8b5cf6",
                      transform: isBranchPoint ? "scale(1.5)" : "scale(1)",
                      border: isBranchPoint ? "2px solid #fbbf24" : "none"
                    }}
                    onClick={() => setCurrentIndex(index)}
                    title={`${event.role} - ${event.timestamp.toLocaleTimeString()}`}
                  />
                );
              })}
            </div>
            
            {/* Current Position Indicator */}
            <div
              className="absolute top-0 w-1 h-12 bg-primary"
              style={{ left: `${(currentIndex / (events.length - 1)) * 100}%` }}
            />
          </div>

          {/* Slider */}
          <Slider
            value={[currentIndex]}
            onValueChange={handleSliderChange}
            max={events.length - 1}
            step={1}
            className="w-full"
          />

          {/* Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentIndex(Math.max(0, currentIndex - 1))}
                disabled={currentIndex === 0}
              >
                <SkipBack className="h-4 w-4" />
              </Button>
              <Button
                variant="default"
                size="icon"
                onClick={handlePlay}
              >
                {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentIndex(Math.min(events.length - 1, currentIndex + 1))}
                disabled={currentIndex === events.length - 1}
              >
                <SkipForward className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-muted-foreground" />
                <select
                  value={playbackSpeed}
                  onChange={(e) => setPlaybackSpeed(Number(e.target.value))}
                  className="bg-background border border-border rounded px-2 py-1 text-sm"
                >
                  <option value={0.5}>0.5x</option>
                  <option value={1}>1x</option>
                  <option value={2}>2x</option>
                  <option value={4}>4x</option>
                </select>
              </div>

              <div className="text-sm text-muted-foreground">
                {currentIndex + 1} / {events.length}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Messages Display */}
      <ScrollArea className="flex-1">
        <div className="max-w-3xl mx-auto px-4 py-6">
          {displayedMessages.map((message) => {
            const isBranchPoint = branchPoints.includes(message.id);
            
            return (
              <div
                key={message.id}
                className={`mb-6 flex gap-4 ${
                  message.role === "user" ? "flex-row-reverse" : ""
                }`}
              >
                <div className="flex-shrink-0">
                  {message.role === "assistant" ? (
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <img
                        src="/images/wormgpt-logo.png"
                        alt="AI"
                        className="h-5 w-5 rounded-full"
                      />
                    </div>
                  ) : (
                    <div className="h-8 w-8 rounded-full bg-accent flex items-center justify-center text-xs font-semibold">
                      U
                    </div>
                  )}
                </div>

                <div className="flex-1 space-y-2">
                  <div className="prose prose-invert prose-sm max-w-none">
                    <Streamdown>{message.content}</Streamdown>
                  </div>
                  {isBranchPoint && onBranchFrom && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => onBranchFrom(message.id)}
                    >
                      Branch from here
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
}

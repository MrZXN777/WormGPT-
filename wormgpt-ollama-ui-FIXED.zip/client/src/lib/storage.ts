export interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
  isPinned?: boolean;
  isArchived?: boolean;
  tags?: string[];
}

export interface AppSettings {
  ollamaUrl: string;
  selectedModel: string;
  temperature: number;
  streamSpeed: number;
  fontSize: number;
  theme: "light" | "dark";
  autoScroll: boolean;
  soundEnabled: boolean;
  notificationsEnabled: boolean;
  voiceEnabled: boolean;
  ttsEnabled: boolean;
}

const DEFAULT_SETTINGS: AppSettings = {
  ollamaUrl: "http://localhost:11434",
  selectedModel: "llama2",
  temperature: 0.7,
  streamSpeed: 50,
  fontSize: 14,
  theme: "dark",
  autoScroll: true,
  soundEnabled: false,
  notificationsEnabled: false,
  voiceEnabled: false,
  ttsEnabled: false,
};

export class StorageService {
  private static CONVERSATIONS_KEY = "wormgpt_conversations";
  private static SETTINGS_KEY = "wormgpt_settings";
  private static DRAFT_KEY = "wormgpt_draft";
  private static FAVORITES_KEY = "wormgpt_favorites";

  // Conversations
  static getConversations(): Conversation[] {
    try {
      const data = localStorage.getItem(this.CONVERSATIONS_KEY);
      if (!data) return [];
      const conversations = JSON.parse(data);
      return conversations.map((c: any) => ({
        ...c,
        createdAt: new Date(c.createdAt),
        updatedAt: new Date(c.updatedAt),
        messages: c.messages.map((m: any) => ({
          ...m,
          timestamp: new Date(m.timestamp),
        })),
      }));
    } catch (error) {
      console.error("Failed to load conversations:", error);
      return [];
    }
  }

  static saveConversations(conversations: Conversation[]): void {
    try {
      localStorage.setItem(this.CONVERSATIONS_KEY, JSON.stringify(conversations));
    } catch (error) {
      console.error("Failed to save conversations:", error);
    }
  }

  static addConversation(conversation: Conversation): void {
    const conversations = this.getConversations();
    conversations.unshift(conversation);
    this.saveConversations(conversations);
  }

  static updateConversation(id: string, updates: Partial<Conversation>): void {
    const conversations = this.getConversations();
    const index = conversations.findIndex((c) => c.id === id);
    if (index !== -1) {
      conversations[index] = {
        ...conversations[index],
        ...updates,
        updatedAt: new Date(),
      };
      this.saveConversations(conversations);
    }
  }

  static deleteConversation(id: string): void {
    const conversations = this.getConversations().filter((c) => c.id !== id);
    this.saveConversations(conversations);
  }

  static clearAllConversations(): void {
    localStorage.removeItem(this.CONVERSATIONS_KEY);
  }

  static exportConversation(conversation: Conversation, format: "json" | "txt" | "md"): string {
    if (format === "json") {
      return JSON.stringify(conversation, null, 2);
    } else if (format === "txt") {
      let text = `${conversation.title}\n${"=".repeat(conversation.title.length)}\n\n`;
      conversation.messages.forEach((msg) => {
        text += `[${msg.role.toUpperCase()}] ${msg.timestamp.toLocaleString()}\n${msg.content}\n\n`;
      });
      return text;
    } else {
      // Markdown
      let md = `# ${conversation.title}\n\n`;
      conversation.messages.forEach((msg) => {
        md += `### ${msg.role === "user" ? "You" : "WormGPT"}\n\n${msg.content}\n\n---\n\n`;
      });
      return md;
    }
  }

  static importConversation(data: string): Conversation | null {
    try {
      const parsed = JSON.parse(data);
      return {
        ...parsed,
        createdAt: new Date(parsed.createdAt),
        updatedAt: new Date(parsed.updatedAt),
        messages: parsed.messages.map((m: any) => ({
          ...m,
          timestamp: new Date(m.timestamp),
        })),
      };
    } catch (error) {
      console.error("Failed to import conversation:", error);
      return null;
    }
  }

  // Settings
  static getSettings(): AppSettings {
    try {
      const data = localStorage.getItem(this.SETTINGS_KEY);
      if (!data) return DEFAULT_SETTINGS;
      return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
    } catch (error) {
      console.error("Failed to load settings:", error);
      return DEFAULT_SETTINGS;
    }
  }

  static saveSettings(settings: Partial<AppSettings>): void {
    try {
      const current = this.getSettings();
      const updated = { ...current, ...settings };
      localStorage.setItem(this.SETTINGS_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error("Failed to save settings:", error);
    }
  }

  // Draft
  static saveDraft(text: string): void {
    localStorage.setItem(this.DRAFT_KEY, text);
  }

  static getDraft(): string {
    return localStorage.getItem(this.DRAFT_KEY) || "";
  }

  static clearDraft(): void {
    localStorage.removeItem(this.DRAFT_KEY);
  }

  // Favorites
  static getFavorites(): string[] {
    try {
      const data = localStorage.getItem(this.FAVORITES_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      return [];
    }
  }

  static saveFavorite(prompt: string): void {
    const favorites = this.getFavorites();
    if (!favorites.includes(prompt)) {
      favorites.push(prompt);
      localStorage.setItem(this.FAVORITES_KEY, JSON.stringify(favorites));
    }
  }

  static removeFavorite(prompt: string): void {
    const favorites = this.getFavorites().filter((f) => f !== prompt);
    localStorage.setItem(this.FAVORITES_KEY, JSON.stringify(favorites));
  }
}

export interface Template {
  id: string;
  title: string;
  prompt: string;
  category: string;
}

export const DEFAULT_TEMPLATES: Template[] = [
  {
    id: "code-review",
    title: "Code Review",
    prompt: "Review the following code and provide suggestions for improvement:\n\n",
    category: "Development"
  },
  {
    id: "explain-code",
    title: "Explain Code",
    prompt: "Explain what this code does in simple terms:\n\n",
    category: "Development"
  },
  {
    id: "debug-code",
    title: "Debug Code",
    prompt: "Help me debug this code. The error is:\n\n",
    category: "Development"
  },
  {
    id: "write-script",
    title: "Write Script",
    prompt: "Write a script that does the following:\n\n",
    category: "Development"
  },
  {
    id: "summarize",
    title: "Summarize Text",
    prompt: "Summarize the following text:\n\n",
    category: "Writing"
  },
  {
    id: "rewrite",
    title: "Rewrite Text",
    prompt: "Rewrite the following text to be more professional:\n\n",
    category: "Writing"
  },
  {
    id: "translate",
    title: "Translate",
    prompt: "Translate the following to [language]:\n\n",
    category: "Writing"
  },
  {
    id: "brainstorm",
    title: "Brainstorm Ideas",
    prompt: "Help me brainstorm ideas for:\n\n",
    category: "Creative"
  },
  {
    id: "research",
    title: "Research Topic",
    prompt: "Research and provide information about:\n\n",
    category: "Research"
  },
  {
    id: "analyze",
    title: "Analyze Data",
    prompt: "Analyze the following data and provide insights:\n\n",
    category: "Analysis"
  }
];

export class TemplateService {
  private static STORAGE_KEY = "wormgpt_templates";

  static getTemplates(): Template[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        const custom = JSON.parse(stored);
        return [...DEFAULT_TEMPLATES, ...custom];
      }
    } catch (error) {
      console.error("Failed to load templates:", error);
    }
    return DEFAULT_TEMPLATES;
  }

  static saveCustomTemplate(template: Omit<Template, 'id'>): void {
    const templates = this.getCustomTemplates();
    const newTemplate: Template = {
      ...template,
      id: Date.now().toString()
    };
    templates.push(newTemplate);
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(templates));
  }

  static getCustomTemplates(): Template[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      return [];
    }
  }

  static deleteCustomTemplate(id: string): void {
    const templates = this.getCustomTemplates().filter(t => t.id !== id);
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(templates));
  }

  static getTemplatesByCategory(category: string): Template[] {
    return this.getTemplates().filter(t => t.category === category);
  }

  static getCategories(): string[] {
    const templates = this.getTemplates();
    return Array.from(new Set(templates.map(t => t.category)));
  }
}

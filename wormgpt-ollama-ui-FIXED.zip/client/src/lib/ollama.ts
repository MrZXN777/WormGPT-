import { SYSTEM_PROMPT } from "./constants";

export interface OllamaModel {
  name: string;
  modified_at: string;
  size: number;
}

export interface OllamaMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export class OllamaService {
  private baseUrl: string;

  constructor(baseUrl: string = "http://localhost:11434") {
    this.baseUrl = baseUrl;
  }

  setBaseUrl(url: string) {
    this.baseUrl = url;
  }

  async testConnection(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`, {
        signal: AbortSignal.timeout(5000) // 5 second timeout
      });
      return response.ok;
    } catch (error) {
      // Expected error when Ollama is not running - don't log to console
      return false;
    }
  }

  async listModels(): Promise<OllamaModel[]> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`, {
        signal: AbortSignal.timeout(5000)
      });
      if (!response.ok) return [];
      const data = await response.json();
      return data.models || [];
    } catch (error) {
      // Expected error when Ollama is not running
      return [];
    }
  }

  async *streamChat(
    model: string,
    messages: OllamaMessage[],
    temperature: number = 0.7,
    onToken?: (token: string) => void
  ): AsyncGenerator<string, void, unknown> {
    // Always prepend system prompt
    const messagesWithSystem: OllamaMessage[] = [
      { role: "system", content: SYSTEM_PROMPT },
      ...messages.filter(m => m.role !== "system")
    ];

    try {
      const response = await fetch(`${this.baseUrl}/api/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model,
          messages: messagesWithSystem,
          stream: true,
          options: {
            temperature,
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (!reader) {
        throw new Error("No reader available");
      }

      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (line.trim()) {
            try {
              const data = JSON.parse(line);
              if (data.message?.content) {
                const token = data.message.content;
                if (onToken) onToken(token);
                yield token;
              }
            } catch (e) {
              console.error("Failed to parse line:", line, e);
            }
          }
        }
      }
    } catch (error) {
      console.error("Stream chat failed:", error);
      throw error;
    }
  }

  async chat(
    model: string,
    messages: OllamaMessage[],
    temperature: number = 0.7
  ): Promise<string> {
    let fullResponse = "";
    for await (const token of this.streamChat(model, messages, temperature)) {
      fullResponse += token;
    }
    return fullResponse;
  }
}

export const ollamaService = new OllamaService();

// Web Search & OSINT Service for WormGPT

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
  source: string;
}

export interface OSINTActivity {
  id: string;
  timestamp: number;
  action: string;
  target: string;
  status: "searching" | "found" | "failed";
  results?: string[];
}

class WebSearchService {
  private activities: OSINTActivity[] = [];
  private isEnabled: boolean = false;
  private activityCallbacks: ((activity: OSINTActivity) => void)[] = [];

  setEnabled(enabled: boolean) {
    this.isEnabled = enabled;
  }

  isSearchEnabled(): boolean {
    return this.isEnabled;
  }

  onActivity(callback: (activity: OSINTActivity) => void) {
    this.activityCallbacks.push(callback);
  }

  private logActivity(activity: OSINTActivity) {
    this.activities.push(activity);
    this.activityCallbacks.forEach((cb) => cb(activity));
  }

  getActivities(): OSINTActivity[] {
    return this.activities;
  }

  clearActivities() {
    this.activities = [];
  }

  // Search multiple sources
  async searchWeb(query: string): Promise<SearchResult[]> {
    if (!this.isEnabled) {
      throw new Error("Web search is disabled. Enable it in settings.");
    }

    const activity: OSINTActivity = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      action: "Web Search",
      target: query,
      status: "searching",
    };
    this.logActivity(activity);

    try {
      // Use multiple search engines via their APIs
      const results: SearchResult[] = [];

      // DuckDuckGo HTML scraping (no API key needed)
      const ddgResults = await this.searchDuckDuckGo(query);
      results.push(...ddgResults);

      // Google Custom Search (if user provides API key)
      // const googleResults = await this.searchGoogle(query);
      // results.push(...googleResults);

      activity.status = "found";
      activity.results = results.map((r) => r.title);
      this.logActivity(activity);

      return results;
    } catch (error) {
      activity.status = "failed";
      this.logActivity(activity);
      throw error;
    }
  }

  private async searchDuckDuckGo(query: string): Promise<SearchResult[]> {
    try {
      const encodedQuery = encodeURIComponent(query);
      const url = `https://html.duckduckgo.com/html/?q=${encodedQuery}`;

      const response = await fetch(url, {
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
      });

      const html = await response.text();
      const results = this.parseDuckDuckGoHTML(html);
      return results;
    } catch (error) {
      console.error("DuckDuckGo search failed:", error);
      return [];
    }
  }

  private parseDuckDuckGoHTML(html: string): SearchResult[] {
    const results: SearchResult[] = [];
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");

    const resultElements = doc.querySelectorAll(".result");

    resultElements.forEach((el) => {
      const titleEl = el.querySelector(".result__a");
      const snippetEl = el.querySelector(".result__snippet");
      const urlEl = el.querySelector(".result__url");

      if (titleEl && snippetEl) {
        results.push({
          title: titleEl.textContent || "",
          url: urlEl?.textContent || "",
          snippet: snippetEl.textContent || "",
          source: "DuckDuckGo",
        });
      }
    });

    return results;
  }

  // OSINT: Find person information
  async findPersonInfo(name: string): Promise<SearchResult[]> {
    if (!this.isEnabled) {
      throw new Error("OSINT is disabled. Enable web search in settings.");
    }

    const activity: OSINTActivity = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      action: "OSINT: Person Lookup",
      target: name,
      status: "searching",
    };
    this.logActivity(activity);

    const queries = [
      `"${name}" email`,
      `"${name}" phone number`,
      `"${name}" address`,
      `"${name}" social media`,
      `"${name}" LinkedIn`,
      `"${name}" Facebook`,
      `"${name}" Twitter`,
      `"${name}" Instagram`,
    ];

    const allResults: SearchResult[] = [];

    for (const query of queries) {
      const results = await this.searchWeb(query);
      allResults.push(...results);
      // Small delay to avoid rate limiting
      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    activity.status = "found";
    activity.results = [`Found ${allResults.length} results for ${name}`];
    this.logActivity(activity);

    return allResults;
  }

  // Download file from URL
  async downloadFile(url: string, filename: string): Promise<void> {
    if (!this.isEnabled) {
      throw new Error("File download is disabled. Enable web search in settings.");
    }

    const activity: OSINTActivity = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      action: "Download File",
      target: url,
      status: "searching",
    };
    this.logActivity(activity);

    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = downloadUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(downloadUrl);

      activity.status = "found";
      activity.results = [`Downloaded: ${filename}`];
      this.logActivity(activity);
    } catch (error) {
      activity.status = "failed";
      this.logActivity(activity);
      throw error;
    }
  }

  // Scrape webpage content
  async scrapeWebpage(url: string): Promise<string> {
    if (!this.isEnabled) {
      throw new Error("Web scraping is disabled. Enable web search in settings.");
    }

    const activity: OSINTActivity = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      action: "Scrape Webpage",
      target: url,
      status: "searching",
    };
    this.logActivity(activity);

    try {
      const response = await fetch(url);
      const html = await response.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");

      // Extract text content
      const textContent = doc.body.textContent || "";

      activity.status = "found";
      activity.results = [`Scraped ${textContent.length} characters`];
      this.logActivity(activity);

      return textContent;
    } catch (error) {
      activity.status = "failed";
      this.logActivity(activity);
      throw error;
    }
  }
}

export const webSearchService = new WebSearchService();

import type { Message } from "./storage";

export interface ContextAnalysis {
  totalTokens: number;
  maxTokens: number;
  usagePercentage: number;
  messagesInContext: number;
  messagesOutOfContext: number;
  healthScore: number; // 0-100
  warnings: string[];
}

export interface MessageTokenInfo {
  messageId: string;
  tokens: number;
  inContext: boolean;
  importance: number; // 0-1
}

export class ContextAnalyzer {
  // Approximate tokens per character (rough estimate)
  private static readonly CHARS_PER_TOKEN = 4;
  
  // Default context window sizes for common models
  private static readonly MODEL_CONTEXT_SIZES: Record<string, number> = {
    "llama3": 8192,
    "llama2": 4096,
    "mistral": 8192,
    "codellama": 16384,
    "gemma": 8192,
    "phi": 2048,
    "default": 4096
  };

  static getModelContextSize(modelName: string): number {
    const key = Object.keys(this.MODEL_CONTEXT_SIZES).find(k => 
      modelName.toLowerCase().includes(k)
    );
    return key ? this.MODEL_CONTEXT_SIZES[key] : this.MODEL_CONTEXT_SIZES.default;
  }

  static estimateTokens(text: string): number {
    // Simple estimation: ~4 characters per token
    return Math.ceil(text.length / this.CHARS_PER_TOKEN);
  }

  static analyzeContext(
    messages: Message[],
    modelName: string,
    systemPromptTokens: number = 500
  ): ContextAnalysis {
    const maxTokens = this.getModelContextSize(modelName);
    let totalTokens = systemPromptTokens;
    const messageTokens: MessageTokenInfo[] = [];

    // Calculate tokens for each message (newest first)
    const reversedMessages = [...messages].reverse();
    
    for (const message of reversedMessages) {
      const tokens = this.estimateTokens(message.content);
      totalTokens += tokens;
      
      messageTokens.push({
        messageId: message.id,
        tokens,
        inContext: totalTokens <= maxTokens,
        importance: this.calculateImportance(message, messages)
      });
    }

    const messagesInContext = messageTokens.filter(m => m.inContext).length;
    const messagesOutOfContext = messageTokens.length - messagesInContext;
    const usagePercentage = (totalTokens / maxTokens) * 100;
    
    // Calculate health score
    const healthScore = this.calculateHealthScore(
      usagePercentage,
      messagesOutOfContext,
      messageTokens
    );

    // Generate warnings
    const warnings = this.generateWarnings(
      usagePercentage,
      messagesOutOfContext,
      totalTokens,
      maxTokens
    );

    return {
      totalTokens,
      maxTokens,
      usagePercentage,
      messagesInContext,
      messagesOutOfContext,
      healthScore,
      warnings
    };
  }

  static getMessageTokenInfo(
    messages: Message[],
    modelName: string,
    systemPromptTokens: number = 500
  ): MessageTokenInfo[] {
    const maxTokens = this.getModelContextSize(modelName);
    let runningTotal = systemPromptTokens;
    const messageTokens: MessageTokenInfo[] = [];

    // Process messages in reverse (newest first)
    const reversedMessages = [...messages].reverse();
    
    for (const message of reversedMessages) {
      const tokens = this.estimateTokens(message.content);
      runningTotal += tokens;
      
      messageTokens.push({
        messageId: message.id,
        tokens,
        inContext: runningTotal <= maxTokens,
        importance: this.calculateImportance(message, messages)
      });
    }

    return messageTokens.reverse(); // Return in original order
  }

  private static calculateImportance(message: Message, allMessages: Message[]): number {
    let importance = 0.5; // Base importance

    // Recent messages are more important
    const messageIndex = allMessages.findIndex(m => m.id === message.id);
    const recencyScore = messageIndex / allMessages.length;
    importance += recencyScore * 0.3;

    // Longer messages might be more important
    const avgLength = allMessages.reduce((sum, m) => sum + m.content.length, 0) / allMessages.length;
    if (message.content.length > avgLength * 1.5) {
      importance += 0.1;
    }

    // User messages slightly more important (they set context)
    if (message.role === "user") {
      importance += 0.1;
    }

    return Math.min(importance, 1);
  }

  private static calculateHealthScore(
    usagePercentage: number,
    messagesOutOfContext: number,
    messageTokens: MessageTokenInfo[]
  ): number {
    let score = 100;

    // Penalize high usage
    if (usagePercentage > 90) score -= 30;
    else if (usagePercentage > 75) score -= 15;
    else if (usagePercentage > 50) score -= 5;

    // Penalize messages out of context
    score -= messagesOutOfContext * 5;

    // Penalize if important messages are out of context
    const importantMessagesLost = messageTokens.filter(
      m => !m.inContext && m.importance > 0.7
    ).length;
    score -= importantMessagesLost * 10;

    return Math.max(0, Math.min(100, score));
  }

  private static generateWarnings(
    usagePercentage: number,
    messagesOutOfContext: number,
    totalTokens: number,
    maxTokens: number
  ): string[] {
    const warnings: string[] = [];

    if (usagePercentage > 95) {
      warnings.push("Critical: Context window nearly full! AI may lose important information.");
    } else if (usagePercentage > 85) {
      warnings.push("Warning: Context window is filling up. Consider summarizing or pruning.");
    } else if (usagePercentage > 70) {
      warnings.push("Notice: Context usage is high. Monitor for context loss.");
    }

    if (messagesOutOfContext > 0) {
      warnings.push(`${messagesOutOfContext} message(s) are outside the context window.`);
    }

    if (totalTokens > maxTokens) {
      const overflow = totalTokens - maxTokens;
      warnings.push(`Context overflow: ${overflow} tokens beyond limit.`);
    }

    return warnings;
  }

  static suggestPruning(messages: Message[], modelName: string): string[] {
    const messageTokens = this.getMessageTokenInfo(messages, modelName);
    const suggestions: string[] = [];

    // Find messages that are out of context and low importance
    const candidatesForPruning = messageTokens
      .filter(m => !m.inContext && m.importance < 0.5)
      .map(m => m.messageId);

    if (candidatesForPruning.length > 0) {
      suggestions.push(`Consider removing ${candidatesForPruning.length} low-importance messages.`);
    }

    // Suggest summarization if many messages are out of context
    const outOfContext = messageTokens.filter(m => !m.inContext).length;
    if (outOfContext > 5) {
      suggestions.push("Consider summarizing older messages to preserve context.");
    }

    return suggestions;
  }
}
